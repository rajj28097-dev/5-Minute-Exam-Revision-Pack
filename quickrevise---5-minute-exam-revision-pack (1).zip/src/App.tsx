import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Flame,
  CheckSquare,
  HelpCircle,
  FileText,
  Clock,
  Printer,
  Upload,
  Share2,
  CheckCheck,
  Check,
  Sparkles,
  Award,
  ChevronRight,
  Bookmark
} from 'lucide-react';
import { SAMPLE_PACKS } from './data/samplePacks';
import { RevisionPack } from './types/revision';
import { Header } from './components/Header';
import { QuickSummaryView } from './components/QuickSummaryView';
import { MustRememberView } from './components/MustRememberView';
import { MCQExamView } from './components/MCQExamView';
import { AnswerKeyView } from './components/AnswerKeyView';
import { ExamPracticeView } from './components/ExamPracticeView';
import { PrintableDocumentView } from './components/PrintableDocumentView';
import { NotesInputModal } from './components/NotesInputModal';

type ActiveTab = 'summary' | 'must_remember' | 'mcqs' | 'answers' | 'practice';

export default function App() {
  const [allPacks, setAllPacks] = useState<RevisionPack[]>(() => {
    try {
      const saved = localStorage.getItem('quickrevise_packs_v3');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
      // Check if previous version had custom user packs
      const oldSaved = localStorage.getItem('quickrevise_packs');
      if (oldSaved) {
        const oldParsed = JSON.parse(oldSaved);
        if (Array.isArray(oldParsed)) {
          const customUserPacks = oldParsed.filter(
            (p: RevisionPack) => !SAMPLE_PACKS.some((sp) => sp.id === p.id)
          );
          return [...SAMPLE_PACKS, ...customUserPacks];
        }
      }
    } catch (e) {
      console.error(e);
    }
    return SAMPLE_PACKS;
  });

  const [activePackId, setActivePackId] = useState<string>(SAMPLE_PACKS[0].id);
  const [activeTab, setActiveTab] = useState<ActiveTab>('summary');
  const [isPrintView, setIsPrintView] = useState<boolean>(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState<boolean>(false);

  const currentPack = allPacks.find((p) => p.id === activePackId) || allPacks[0] || SAMPLE_PACKS[0];

  // Save to localStorage when allPacks change
  useEffect(() => {
    try {
      localStorage.setItem('quickrevise_packs_v3', JSON.stringify(allPacks));
    } catch (e) {
      console.error(e);
    }
  }, [allPacks]);

  const handlePackGenerated = (newPack: RevisionPack) => {
    setAllPacks((prev) => [newPack, ...prev]);
    setActivePackId(newPack.id);
    setActiveTab('summary');
  };

  // Compile full text for the speech synthesizer audio reader
  const summaryAudioText = [
    `Quick 5-minute revision on: ${currentPack.quickSummary.topicTitle}.`,
    currentPack.quickSummary.overview,
    'Key Speed Revision Points:',
    ...currentPack.quickSummary.speedRevisionPoints,
    ...currentPack.quickSummary.sections.map((s) => `${s.heading}. ${s.keyTakeaway}. ${s.bulletPoints.join('. ')}.`)
  ].join(' ');

  if (isPrintView) {
    return (
      <PrintableDocumentView
        pack={currentPack}
        onBackToApp={() => setIsPrintView(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Application Header */}
      <Header
        currentPack={currentPack}
        availablePacks={allPacks}
        onSelectPack={(pack) => setActivePackId(pack.id)}
        onOpenUpload={() => setIsUploadModalOpen(true)}
        onPrint={() => setIsPrintView(true)}
        summaryAudioText={summaryAudioText}
      />

      {/* Main Content Area */}
      <main className="grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6">
        {/* Navigation Tabs Bar */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-1.5 shadow-xs overflow-x-auto">
          <div className="flex items-center gap-1 min-w-max">
            <button
              onClick={() => setActiveTab('summary')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
                activeTab === 'summary'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>1. 5-Min Summary</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                activeTab === 'summary' ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
              }`}>
                {currentPack.quickSummary.estimatedReadTime || '5m'}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('must_remember')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
                activeTab === 'must_remember'
                  ? 'bg-amber-500 text-white shadow-md shadow-amber-500/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Flame className="w-4 h-4 fill-current" />
              <span>2. Must Remember</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                activeTab === 'must_remember' ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
              }`}>
                {currentPack.mustRemember.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('mcqs')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
                activeTab === 'mcqs'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <CheckSquare className="w-4 h-4" />
              <span>3. 20 MCQs</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                activeTab === 'mcqs' ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
              }`}>
                20 Qs
              </span>
            </button>

            <button
              onClick={() => setActiveTab('answers')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
                activeTab === 'answers'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <CheckCheck className="w-4 h-4" />
              <span>4 & 5. Answer Key & Rationale</span>
            </button>

            <button
              onClick={() => setActiveTab('practice')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
                activeTab === 'practice'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>6. Exam Practice</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                activeTab === 'practice' ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
              }`}>
                13 Qs
              </span>
            </button>
          </div>
        </div>

        {/* Tab Content Display */}
        {activeTab === 'summary' && (
          <QuickSummaryView
            summary={currentPack.quickSummary}
            onGoToMCQs={() => setActiveTab('mcqs')}
            onGoToMustRemember={() => setActiveTab('must_remember')}
          />
        )}

        {activeTab === 'must_remember' && (
          <MustRememberView points={currentPack.mustRemember} />
        )}

        {activeTab === 'mcqs' && (
          <MCQExamView
            mcqs={currentPack.mcqs}
            onViewAnswerKey={() => setActiveTab('answers')}
          />
        )}

        {activeTab === 'answers' && (
          <AnswerKeyView
            answerKey={currentPack.answerKey}
            shortExplanations={currentPack.shortExplanations}
            mcqs={currentPack.mcqs}
          />
        )}

        {activeTab === 'practice' && (
          <ExamPracticeView practice={currentPack.examPractice} />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-900/70 py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700 dark:text-slate-300">QuickRevise Engine</span>
            <span>•</span>
            <span>Last-minute 5-minute academic exam revision packs</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Summary</span>
            <span>•</span>
            <span>Must Remember</span>
            <span>•</span>
            <span>20 MCQs</span>
            <span>•</span>
            <span>Answer Key</span>
            <span>•</span>
            <span>Practice</span>
          </div>
        </div>
      </footer>

      {/* Upload Notes Modal */}
      <NotesInputModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onPackGenerated={handlePackGenerated}
      />
    </div>
  );
}
