import React, { useState } from 'react';
import {
  FileText,
  HelpCircle,
  Eye,
  EyeOff,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Award,
  BookOpen,
  Copy,
  Check
} from 'lucide-react';
import { ExamPracticeSection, PracticeQuestion } from '../types/revision';

interface ExamPracticeViewProps {
  practice: ExamPracticeSection;
}

export const ExamPracticeView: React.FC<ExamPracticeViewProps> = ({ practice }) => {
  const [activeTab, setActiveTab] = useState<'viq' | 'short' | 'long'>('viq');
  const [revealedAnswers, setRevealedAnswers] = useState<Set<number>>(new Set());
  const [copied, setCopied] = useState(false);

  const toggleAnswer = (id: number) => {
    setRevealedAnswers((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const revealAllCurrentTab = () => {
    const questions =
      activeTab === 'viq'
        ? practice.veryImportantQuestions
        : activeTab === 'short'
        ? practice.shortAnswerQuestions
        : practice.longAnswerQuestions;
    const allIds = new Set(questions.map((q) => q.id));
    setRevealedAnswers(allIds);
  };

  const hideAllCurrentTab = () => {
    setRevealedAnswers(new Set());
  };

  const handleCopyPractice = () => {
    const text = [
      '=== 6. EXAM PRACTICE QUESTIONS ===',
      '',
      '--- 5 VERY IMPORTANT QUESTIONS (VIQs) ---',
      ...practice.veryImportantQuestions.map(
        (q, i) => `${i + 1}. [${q.weightage || 'VIQ'}] ${q.question}\nModel Answer:\n${q.modelAnswer}\n`
      ),
      '',
      '--- 5 SHORT-ANSWER QUESTIONS ---',
      ...practice.shortAnswerQuestions.map(
        (q, i) => `${i + 1}. [${q.weightage || 'Short'}] ${q.question}\nModel Answer:\n${q.modelAnswer}\n`
      ),
      '',
      '--- 3 LONG-ANSWER QUESTIONS ---',
      ...practice.longAnswerQuestions.map(
        (q, i) => `${i + 1}. [${q.weightage || 'Long'}] ${q.question}\nModel Answer:\n${q.modelAnswer}\n`
      ),
    ].join('\n');

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const renderQuestionList = (questions: PracticeQuestion[], tagLabel: string, defaultColor: string) => {
    return (
      <div className="space-y-4">
        {questions.map((q, idx) => {
          const isRevealed = revealedAnswers.has(q.id);

          return (
            <div
              key={q.id || idx}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm space-y-4 transition hover:border-slate-300 dark:hover:border-slate-700"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-2.5">
                  <span className={`px-2.5 py-1 rounded-lg text-xs font-bold ${defaultColor} shrink-0 mt-0.5`}>
                    #{idx + 1}
                  </span>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                        {tagLabel}
                      </span>
                      {q.weightage && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          {q.weightage}
                        </span>
                      )}
                    </div>
                    <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-snug">
                      {q.question}
                    </h3>
                  </div>
                </div>

                <button
                  onClick={() => toggleAnswer(q.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-medium transition shrink-0 cursor-pointer"
                >
                  {isRevealed ? (
                    <>
                      <EyeOff className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Hide Solution</span>
                    </>
                  ) : (
                    <>
                      <Eye className="w-3.5 h-3.5 text-indigo-500" />
                      <span className="hidden sm:inline">Reveal Solution</span>
                    </>
                  )}
                </button>
              </div>

              {/* Key points to score marks */}
              {q.keyPoints && q.keyPoints.length > 0 && (
                <div className="bg-amber-500/10 border border-amber-500/20 p-3 rounded-xl text-xs space-y-1.5">
                  <div className="font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
                    Essential Marking Rubric / Key Points to Write:
                  </div>
                  <ul className="space-y-1 pl-5 list-disc text-amber-900/90 dark:text-amber-200/90 leading-relaxed">
                    {q.keyPoints.map((kp, kIdx) => (
                      <li key={kIdx}>{kp}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Model Answer (Collapsible or Revealed) */}
              {isRevealed && (
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2 animate-fadeIn">
                  <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                    <Award className="w-4 h-4 text-emerald-500" />
                    University Model Answer:
                  </div>
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line font-normal">
                    {q.modelAnswer}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow-md shadow-indigo-600/20">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                  6. Exam Practice
                </h2>
                <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-800">
                  Descriptive Practice
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                5 Very Important Questions, 5 Short-Answer Questions, and 3 Long-Answer Questions for written papers.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={revealAllCurrentTab}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-semibold transition"
            >
              Reveal All Answers
            </button>
            <button
              onClick={hideAllCurrentTab}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-semibold transition"
            >
              Hide All
            </button>
            <button
              onClick={handleCopyPractice}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-sm transition"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Questions'}</span>
            </button>
          </div>
        </div>

        {/* Sub-Tabs: 5 VIQ, 5 Short, 3 Long */}
        <div className="flex gap-2 border-b border-slate-200 dark:border-slate-800 pt-2">
          <button
            onClick={() => setActiveTab('viq')}
            className={`pb-3 px-4 text-xs font-bold transition border-b-2 flex items-center gap-2 cursor-pointer ${
              activeTab === 'viq'
                ? 'border-rose-500 text-rose-600 dark:text-rose-400'
                : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            <span>5 Very Important Questions</span>
            <span className="w-5 h-5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 text-[10px] flex items-center justify-center font-extrabold">
              5
            </span>
          </button>

          <button
            onClick={() => setActiveTab('short')}
            className={`pb-3 px-4 text-xs font-bold transition border-b-2 flex items-center gap-2 cursor-pointer ${
              activeTab === 'short'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            <span>5 Short-Answer Questions</span>
            <span className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-[10px] flex items-center justify-center font-extrabold">
              5
            </span>
          </button>

          <button
            onClick={() => setActiveTab('long')}
            className={`pb-3 px-4 text-xs font-bold transition border-b-2 flex items-center gap-2 cursor-pointer ${
              activeTab === 'long'
                ? 'border-purple-500 text-purple-600 dark:text-purple-400'
                : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            <span>3 Long-Answer Questions</span>
            <span className="w-5 h-5 rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 text-[10px] flex items-center justify-center font-extrabold">
              3
            </span>
          </button>
        </div>
      </div>

      {/* Tab Panels */}
      {activeTab === 'viq' &&
        renderQuestionList(
          practice.veryImportantQuestions,
          'High-Yield University VIQ',
          'bg-rose-600 text-white'
        )}

      {activeTab === 'short' &&
        renderQuestionList(
          practice.shortAnswerQuestions,
          'Direct Exam Short Question (2-3 Marks)',
          'bg-blue-600 text-white'
        )}

      {activeTab === 'long' &&
        renderQuestionList(
          practice.longAnswerQuestions,
          'Comprehensive Long Question (8-15 Marks)',
          'bg-purple-600 text-white'
        )}
    </div>
  );
};
