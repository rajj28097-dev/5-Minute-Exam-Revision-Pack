import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Play, Pause, FastForward, RotateCcw } from 'lucide-react';

interface AudioPlayerBarProps {
  textToRead: string;
  topicTitle: string;
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({ textToRead, topicTitle }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [rate, setRate] = useState(1.1); // default slightly brisk for speed revision
  const [isSupported, setIsSupported] = useState(true);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    if (!('speechSynthesis' in window)) {
      setIsSupported(false);
      return;
    }

    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  useEffect(() => {
    // When text changes, stop any previous speaking
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    }
  }, [textToRead]);

  if (!isSupported) return null;

  const handlePlayPause = () => {
    if (!('speechSynthesis' in window)) return;

    if (isPlaying) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    } else {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(textToRead);
      utterance.rate = rate;
      utterance.pitch = 1.0;

      utterance.onend = () => {
        setIsPlaying(false);
      };
      utterance.onerror = () => {
        setIsPlaying(false);
      };

      utteranceRef.current = utterance;
      window.speechSynthesis.speak(utterance);
      setIsPlaying(true);
    }
  };

  const handleStop = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    }
  };

  const cycleSpeed = () => {
    const speeds = [1.0, 1.2, 1.5, 1.75];
    const nextIndex = (speeds.indexOf(rate) + 1) % speeds.length;
    const newRate = speeds[nextIndex];
    setRate(newRate);

    if (isPlaying) {
      handleStop();
      setTimeout(() => {
        const utterance = new SpeechSynthesisUtterance(textToRead);
        utterance.rate = newRate;
        utterance.onend = () => setIsPlaying(false);
        utterance.onerror = () => setIsPlaying(false);
        utteranceRef.current = utterance;
        window.speechSynthesis.speak(utterance);
        setIsPlaying(true);
      }, 50);
    }
  };

  return (
    <div className="flex items-center gap-2 bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200/70 dark:border-indigo-800/60 px-3 py-1.5 rounded-full text-xs text-indigo-900 dark:text-indigo-200 shadow-sm">
      <div className="flex items-center gap-1.5">
        <Volume2 className={`w-4 h-4 text-indigo-600 dark:text-indigo-400 ${isPlaying ? 'animate-bounce' : ''}`} />
        <span className="font-semibold text-indigo-800 dark:text-indigo-300 hidden md:inline">
          Listen Mode:
        </span>
      </div>

      <button
        onClick={handlePlayPause}
        className="flex items-center gap-1 bg-indigo-600 hover:bg-indigo-700 text-white font-medium px-2.5 py-1 rounded-full text-xs transition active:scale-95"
        title={isPlaying ? 'Pause Speech' : 'Read Summary Aloud'}
      >
        {isPlaying ? (
          <>
            <Pause className="w-3 h-3 fill-current" /> Pause
          </>
        ) : (
          <>
            <Play className="w-3 h-3 fill-current" /> Read Aloud
          </>
        )}
      </button>

      {isPlaying && (
        <button
          onClick={handleStop}
          className="p-1 hover:bg-indigo-200/60 dark:hover:bg-indigo-900 rounded-full transition text-indigo-700 dark:text-indigo-300"
          title="Stop"
        >
          <RotateCcw className="w-3 h-3" />
        </button>
      )}

      <button
        onClick={cycleSpeed}
        className="px-2 py-0.5 rounded-md hover:bg-indigo-200/50 dark:hover:bg-indigo-900 font-mono text-[11px] font-semibold text-indigo-700 dark:text-indigo-300 transition"
        title="Cycle speech speed"
      >
        {rate}x
      </button>
    </div>
  );
};
