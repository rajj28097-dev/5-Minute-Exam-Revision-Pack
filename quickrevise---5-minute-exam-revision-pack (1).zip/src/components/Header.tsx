import React from 'react';
import {
  GraduationCap,
  Sparkles,
  Upload,
  Printer,
  BookOpen,
  ChevronDown,
  Layers,
  FileText
} from 'lucide-react';
import { CramTimer } from './CramTimer';
import { AudioPlayerBar } from './AudioPlayerBar';
import { RevisionPack } from '../types/revision';

interface HeaderProps {
  currentPack: RevisionPack;
  availablePacks: RevisionPack[];
  onSelectPack: (pack: RevisionPack) => void;
  onOpenUpload: () => void;
  onPrint: () => void;
  summaryAudioText: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentPack,
  availablePacks,
  onSelectPack,
  onOpenUpload,
  onPrint,
  summaryAudioText,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-950/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Logo & App Name */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-blue-600 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 shrink-0">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base sm:text-lg tracking-tight text-slate-900 dark:text-white truncate">
                  QuickRevise
                </span>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                  5-Min Exam Pack
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate hidden md:block">
                University Exam Revision & 20-MCQ Cram Pack
              </p>
            </div>
          </div>

          {/* Quick Pack Switcher for easy testing */}
          <div className="hidden lg:flex items-center">
            <div className="relative group">
              <button className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800/80 hover:bg-slate-200/70 dark:hover:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 transition">
                <Layers className="w-3.5 h-3.5 text-indigo-500" />
                <span className="max-w-[200px] truncate">{currentPack.title}</span>
                <ChevronDown className="w-3 h-3 text-slate-400 group-hover:rotate-180 transition-transform" />
              </button>
              <div className="absolute top-full left-0 mt-1 w-80 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl py-1.5 hidden group-hover:block z-50">
                <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Select High-Yield Revision Pack
                </div>
                {availablePacks.map((pack) => (
                  <button
                    key={pack.id}
                    onClick={() => onSelectPack(pack)}
                    className={`w-full text-left px-3 py-2 text-xs flex items-start gap-2 hover:bg-slate-50 dark:hover:bg-slate-800 transition ${
                      currentPack.id === pack.id
                        ? 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 font-semibold'
                        : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <BookOpen className="w-3.5 h-3.5 text-indigo-500 mt-0.5 shrink-0" />
                    <div>
                      <div className="font-medium truncate">{pack.title}</div>
                      <div className="text-[10px] text-slate-400 line-clamp-1">{pack.sourceNoteSummary}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Action Tools: Cram Timer, Audio Player, Print, and Upload CTA */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <div className="hidden sm:block">
              <AudioPlayerBar textToRead={summaryAudioText} topicTitle={currentPack.title} />
            </div>

            <CramTimer initialSeconds={300} />

            <button
              onClick={onPrint}
              title="Print Revision Sheet or Save as PDF"
              className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition border border-slate-200 dark:border-slate-700"
            >
              <Printer className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenUpload}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white text-xs font-semibold rounded-lg shadow-sm shadow-indigo-600/20 transition cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Revise My Notes</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
