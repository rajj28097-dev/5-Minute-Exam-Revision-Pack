import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  FileText,
  X,
  FileCheck,
  AlertCircle,
  Sparkles,
  Loader2,
  BookOpen,
  Image as ImageIcon,
  Check,
  ArrowRight,
  Key,
  ShieldCheck,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { RevisionPack } from '../types/revision';
import { generateRevisionPackClient, getGeminiApiKey } from '../services/geminiRevisionService';

interface NotesInputModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPackGenerated: (pack: RevisionPack) => void;
}

export const NotesInputModal: React.FC<NotesInputModalProps> = ({
  isOpen,
  onClose,
  onPackGenerated,
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'paste'>('paste');
  const [textNotes, setTextNotes] = useState('');
  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    size: number;
    mimeType: string;
    base64Data: string;
  } | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStep, setGenerationStep] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [customApiKey, setCustomApiKey] = useState<string>(() => {
    return localStorage.getItem('quickrevise_user_api_key') || '';
  });
  const [showKeyConfig, setShowKeyConfig] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const envKeyPresent = Boolean(
    import.meta.env.VITE_GEMINI_API_KEY &&
    import.meta.env.VITE_GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'
  );

  useEffect(() => {
    if (!envKeyPresent && !customApiKey) {
      setShowKeyConfig(true);
    }
  }, [envKeyPresent, customApiKey]);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 25 * 1024 * 1024) {
      setErrorMessage('File size exceeds 25MB limit. Please upload a smaller note or paste the text.');
      return;
    }

    setErrorMessage(null);
    const reader = new FileReader();

    reader.onload = () => {
      const result = reader.result as string;
      const base64Data = result.split(',')[1] || result;
      setUploadedFile({
        name: file.name,
        size: file.size,
        mimeType: file.type || 'text/plain',
        base64Data,
      });
      setActiveTab('upload');
    };

    reader.onerror = () => {
      setErrorMessage('Failed to read the file. Please try pasting the text.');
    };

    reader.readAsDataURL(file);
  };

  const loadSampleNotes = (topic: 'dbms' | 'ml') => {
    if (topic === 'dbms') {
      setTextNotes(`Database Management Systems: Transactions, ACID Properties & Concurrency Control

A transaction is a logical unit of database processing that includes one or more database access operations.
ACID Properties:
1. Atomicity: "All or nothing". Either all operations of the transaction are executed and reflected in the database, or none are. Managed by Recovery Manager (Undo/Redo logs).
2. Consistency: Execution of a transaction in isolation preserves database consistency (preserves all integrity constraints like primary/foreign keys).
3. Isolation: Although multiple transactions may execute concurrently, the system guarantees that for every pair of transactions Ti and Tj, it appears to Ti that either Tj finished execution before Ti started, or Tj started after Ti finished. Controlled by Concurrency Control Manager.
4. Durability: Once a transaction commits, its changes persist in non-volatile storage even if the system crashes immediately afterwards. Managed by Recovery Manager (WAL - Write-Ahead Logging).

Serializability & Anomalies:
- Serial Schedule: A schedule where transactions run sequentially one after another with no interleaving. Always consistent.
- Conflict Serializability: A schedule S is conflict serializable if it is conflict equivalent to some serial schedule S'. Two operations conflict if they belong to different transactions, access the same data item, and at least one is a write operation (W-R, R-W, W-W).
- Precedence Graph (Serialization Graph): Construct directed graph where Ti -> Tj if an operation of Ti conflicts with an operation of Tj and Ti executes first. If the precedence graph has NO cycles, the schedule is conflict serializable.
- View Serializability: Broader than conflict serializability; NP-complete to test. Permits blind writes (write without prior read).

Concurrency Anomalies:
1. Dirty Read (Write-Read Conflict): T1 modifies item X, T2 reads X before T1 commits, then T1 rolls back.
2. Lost Update (Write-Write Conflict): T1 and T2 both read X and write new values concurrently, overwriting each other's changes.
3. Unrepeatable Read (Read-Write Conflict): T1 reads item X, T2 modifies or deletes X and commits, T1 reads X again and finds different value.
4. Phantom Read: T1 queries a set of rows satisfying a condition; T2 inserts or deletes rows matching that condition; T1 re-executes query and sees different row count.

Locking Protocols:
- Two-Phase Locking (2PL):
  * Growing Phase: Transaction may obtain locks, but cannot release any lock.
  * Shrinking Phase: Transaction may release locks, but cannot obtain any new locks.
  * 2PL guarantees Conflict Serializability, but does NOT prevent Cascading Rollbacks or Deadlocks!
- Strict 2PL: Transaction must hold all exclusive (write) locks until it commits or aborts. Prevents cascading aborts.
- Rigorous 2PL: Holds ALL locks (shared and exclusive) until commit/abort. Ensures serial order is commit order.

Deadlock Handling in DBMS:
- Wait-Die Scheme (Non-preemptive): If older transaction Ti requests resource held by younger Tj, Ti is allowed to wait. If younger Ti requests resource held by older Tj, Ti dies (rolls back).
- Wound-Wait Scheme (Preemptive): If older Ti requests resource held by younger Tj, Ti wounds (preempts) Tj. If younger Ti requests resource held by older Tj, Ti waits.`);
      setActiveTab('paste');
    } else if (topic === 'ml') {
      setTextNotes(`Machine Learning: Supervised Classification, Loss Functions & Evaluation Metrics

Supervised Learning Fundamentals:
- Given labeled training data {(x_i, y_i)}, learn a mapping function f(x) -> y that minimizes expected loss on unseen test data.
- Parametric vs Non-Parametric: Parametric models (Linear Regression, Logistic Regression) assume fixed form with finite parameters. Non-parametric models (k-Nearest Neighbors, Decision Trees, Kernel SVM) grow parameter count with dataset size.

Bias-Variance Tradeoff:
- Total Expected Error = Bias^2 + Variance + Irreducible Error.
- High Bias (Underfitting): Model is overly simplistic and cannot capture underlying data trends (low training accuracy, low validation accuracy). Solution: Increase model complexity, add polynomial features, reduce regularization (decrease lambda).
- High Variance (Overfitting): Model fits training noise and generalizes poorly to validation data (high training accuracy, low validation accuracy). Solution: Add training data, prune trees, increase regularization (L1 Lasso, L2 Ridge), apply dropout or feature selection.

Regularization:
- L2 Regularization (Ridge): Penalty term = lambda * sum(w_i^2). Drives weights toward zero smoothly without making them exactly zero.
- L1 Regularization (Lasso): Penalty term = lambda * sum(|w_i|). Creates sparse weight vectors by driving non-essential coefficients strictly to zero (acts as automatic feature selection).
- Elastic Net: Combines L1 and L2 penalties with mixing ratio alpha.

Classification Evaluation Metrics:
- Confusion Matrix: True Positive (TP), True Negative (TN), False Positive (FP, Type I error), False Negative (FN, Type II error).
- Precision = TP / (TP + FP). Measures proportion of positive predictions that were truly correct. Critical in spam filtering or loan approval.
- Recall (Sensitivity, True Positive Rate) = TP / (TP + FN). Measures proportion of actual positives successfully identified. Critical in medical diagnosis or fraud detection where false negatives are catastrophic.
- Specificity (True Negative Rate) = TN / (TN + FP).
- F1-Score = 2 * (Precision * Recall) / (Precision + Recall). Harmonic mean of Precision and Recall. Preferred over arithmetic mean because it penalizes extreme imbalances.
- ROC Curve: Plots True Positive Rate (Recall) vs False Positive Rate (1 - Specificity) across varying classification thresholds.
- AUC-ROC: Area Under ROC Curve. AUC = 1.0 represents perfect classifier; AUC = 0.5 represents random guessing.`);
      setActiveTab('paste');
    }
  };

  const handleSaveApiKey = (key: string) => {
    setCustomApiKey(key);
    if (key.trim()) {
      localStorage.setItem('quickrevise_user_api_key', key.trim());
    } else {
      localStorage.removeItem('quickrevise_user_api_key');
    }
  };

  const handleGenerate = async () => {
    if (!textNotes.trim() && !uploadedFile) {
      setErrorMessage('Please either paste note text or upload a document file.');
      return;
    }

    const effectiveKey = getGeminiApiKey(customApiKey);
    if (!effectiveKey) {
      setErrorMessage(
        'Please enter your Gemini API Key below or configure VITE_GEMINI_API_KEY in Netlify settings.'
      );
      setShowKeyConfig(true);
      return;
    }

    setIsGenerating(true);
    setErrorMessage(null);

    const steps = [
      'Extracting and verifying core note concepts...',
      'Synthesizing 5-Minute Quick Summary & Highlighting laws...',
      'Extracting "Must Remember" high-yield exam takeaways...',
      'Formulating 20 university-grade MCQs (concept, tricky, comparison)...',
      'Generating Answer Key (1. A, 2. C...) and 1-2 line justifications...',
      'Drafting 5 VIQs, 5 Short, and 3 Long practice questions...',
    ];

    let currentStepIdx = 0;
    setGenerationStep(steps[0]);
    const stepInterval = setInterval(() => {
      currentStepIdx = (currentStepIdx + 1) % steps.length;
      setGenerationStep(steps[currentStepIdx]);
    }, 1800);

    try {
      const pack = await generateRevisionPackClient({
        textNotes: textNotes.trim() || undefined,
        fileData: uploadedFile?.base64Data,
        mimeType: uploadedFile?.mimeType,
        fileName: uploadedFile?.name,
        userApiKey: customApiKey,
      });

      clearInterval(stepInterval);
      onPackGenerated(pack);
      onClose();
    } catch (err: any) {
      clearInterval(stepInterval);
      setErrorMessage(err.message || 'Something went wrong during generation. Please verify your Gemini API key.');
    } finally {
      setIsGenerating(false);
    }
  };

  const wordCount = textNotes.trim() ? textNotes.trim().split(/\s+/).length : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        {/* Modal Header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-600/20">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Generate 5-Minute Exam Revision Pack
              </h2>
              <p className="text-xs text-slate-500">
                Direct browser AI generation • No backend server needed • Netlify ready
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isGenerating}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4 grow">
          {/* API Key Banner / Config */}
          <div className="bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 font-semibold text-slate-700 dark:text-slate-300">
                <Key className="w-3.5 h-3.5 text-indigo-500" />
                <span>Gemini API Key:</span>
                {envKeyPresent ? (
                  <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-medium flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-500" />
                    Detected via VITE_GEMINI_API_KEY
                  </span>
                ) : customApiKey ? (
                  <span className="text-[11px] px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 font-medium">
                    Stored in browser
                  </span>
                ) : (
                  <span className="text-[11px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-medium">
                    Key required
                  </span>
                )}
              </div>

              <button
                type="button"
                onClick={() => setShowKeyConfig(!showKeyConfig)}
                className="text-indigo-600 dark:text-indigo-400 font-medium hover:underline flex items-center gap-0.5"
              >
                <span>{showKeyConfig ? 'Hide' : 'Configure Key'}</span>
                {showKeyConfig ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>
            </div>

            {showKeyConfig && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 space-y-1.5">
                <input
                  type="password"
                  value={customApiKey}
                  onChange={(e) => handleSaveApiKey(e.target.value)}
                  placeholder={envKeyPresent ? 'Using VITE_GEMINI_API_KEY (or enter custom key)' : 'Enter your Gemini API key (AIzaSy...)'}
                  className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-xs font-mono text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <p className="text-[11px] text-slate-500">
                  On Netlify: add <code>VITE_GEMINI_API_KEY</code> in Site settings &gt; Environment variables, or paste it here directly. Stored securely in your browser.
                </p>
              </div>
            )}
          </div>

          {/* Quick Demo Buttons */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700/80 flex items-center justify-between gap-2 flex-wrap">
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-indigo-500" /> Quick Load Sample Notes:
            </span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => loadSampleNotes('dbms')}
                className="px-2.5 py-1 bg-white dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-950 text-indigo-700 dark:text-indigo-300 rounded-md text-xs font-medium border border-slate-200 dark:border-slate-600 transition"
              >
                DBMS: Transactions & 2PL
              </button>
              <button
                type="button"
                onClick={() => loadSampleNotes('ml')}
                className="px-2.5 py-1 bg-white dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-950 text-indigo-700 dark:text-indigo-300 rounded-md text-xs font-medium border border-slate-200 dark:border-slate-600 transition"
              >
                ML: Bias-Variance & Metrics
              </button>
            </div>
          </div>

          {/* Input Method Selector */}
          <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('paste')}
              className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-2 transition ${
                activeTab === 'paste'
                  ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Paste Notes / Lecture Text</span>
            </button>
            <button
              onClick={() => setActiveTab('upload')}
              className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-2 transition ${
                activeTab === 'upload'
                  ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload PDF / Image / Doc</span>
            </button>
          </div>

          {/* Paste Tab */}
          {activeTab === 'paste' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Paste your lecture notes, syllabus chapter, or revision points:</span>
                <span>{wordCount} words</span>
              </div>
              <textarea
                value={textNotes}
                onChange={(e) => setTextNotes(e.target.value)}
                placeholder="Paste your notes here... (e.g., definitions, formulas, theories, laws, or lecture transcripts)"
                rows={10}
                className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 text-xs sm:text-sm font-sans focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none leading-relaxed"
              />
            </div>
          )}

          {/* Upload Tab */}
          {activeTab === 'upload' && (
            <div className="space-y-3">
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.png,.jpg,.jpeg,.webp,.txt,.md"
                onChange={handleFileChange}
                className="hidden"
              />

              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 rounded-2xl p-8 text-center cursor-pointer bg-slate-50/50 dark:bg-slate-950/50 transition flex flex-col items-center justify-center gap-3"
              >
                <div className="w-12 h-12 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold text-sm text-slate-900 dark:text-white">
                    Click to browse notes or drag & drop here
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    Supports PDF, Textbook Photos (PNG, JPG), Markdown, or Text files (Max 25MB)
                  </div>
                </div>
              </div>

              {uploadedFile && (
                <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 rounded-xl flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <FileCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                      {uploadedFile.name}
                    </span>
                    <span className="text-slate-400 text-[10px]">
                      ({(uploadedFile.size / 1024).toFixed(1)} KB)
                    </span>
                  </div>
                  <button
                    onClick={() => setUploadedFile(null)}
                    className="text-rose-500 hover:text-rose-700 p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Error notice */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 flex items-start gap-2 text-xs text-rose-800 dark:text-rose-300">
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
              <span className="leading-snug">{errorMessage}</span>
            </div>
          )}

          {/* Generating progress state */}
          {isGenerating && (
            <div className="p-5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-center space-y-3">
              <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mx-auto" />
              <div>
                <div className="font-bold text-sm text-slate-900 dark:text-white">
                  Synthesizing 5-Minute Exam Revision Pack...
                </div>
                <div className="text-xs text-indigo-600 dark:text-indigo-400 mt-1 font-medium animate-pulse">
                  {generationStep}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-6 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50 dark:bg-slate-900">
          <div className="text-[11px] text-slate-500 hidden sm:block">
            Strict adherence to 6 sections: Summary, Must Remember, 20 MCQs, Answer Key, Explanations, Exam Practice.
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <button
              onClick={onClose}
              disabled={isGenerating}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleGenerate}
              disabled={isGenerating || (!textNotes.trim() && !uploadedFile)}
              className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-md shadow-indigo-600/20 flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Analyzing Notes...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>Generate Revision Pack</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
