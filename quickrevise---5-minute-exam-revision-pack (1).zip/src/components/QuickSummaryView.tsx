import React, { useState } from 'react';
import {
  Clock,
  Zap,
  Bookmark,
  CheckCircle2,
  BookOpen,
  Filter,
  Flame,
  FileQuestion,
  HelpCircle,
  Copy,
  Check
} from 'lucide-react';
import { QuickSummary, KeyHighlight } from '../types/revision';

interface QuickSummaryViewProps {
  summary: QuickSummary;
  onGoToMCQs?: () => void;
  onGoToMustRemember?: () => void;
}

export const QuickSummaryView: React.FC<QuickSummaryViewProps> = ({
  summary,
  onGoToMCQs,
  onGoToMustRemember,
}) => {
  const [activeHighlightFilter, setActiveHighlightFilter] = useState<string>('all');
  const [copied, setCopied] = useState(false);

  const filterTypes = [
    { id: 'all', label: 'All Highlights' },
    { id: 'definition', label: 'Definitions' },
    { id: 'formula', label: 'Formulas & Rules' },
    { id: 'difference', label: 'Differences & Versus' },
    { id: 'fact', label: 'Key Facts' },
  ];

  const handleCopySummary = () => {
    const text = [
      `# 5-MINUTE QUICK SUMMARY: ${summary.topicTitle}`,
      `Estimated Read Time: ${summary.estimatedReadTime}`,
      '',
      summary.overview,
      '',
      '## 60-Second Speed Blitz:',
      ...summary.speedRevisionPoints.map((p) => `• ${p}`),
      '',
      ...summary.sections.map((s) => [
        `### ${s.heading}`,
        `Key Takeaway: ${s.keyTakeaway}`,
        ...s.bulletPoints.map((b) => `• ${b}`),
        ''
      ].join('\n'))
    ].join('\n');

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getHighlightBadge = (highlight: KeyHighlight) => {
    switch (highlight.type) {
      case 'definition':
        return {
          bg: 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-200',
          badge: 'bg-blue-600 text-white',
          label: 'Definition',
        };
      case 'formula':
        return {
          bg: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200',
          badge: 'bg-amber-600 text-white',
          label: 'Formula / Law',
        };
      case 'difference':
        return {
          bg: 'bg-purple-50 dark:bg-purple-950/40 border-purple-200 dark:border-purple-800 text-purple-900 dark:text-purple-200',
          badge: 'bg-purple-600 text-white',
          label: 'Difference',
        };
      case 'advantage_disadvantage':
        return {
          bg: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200',
          badge: 'bg-emerald-600 text-white',
          label: 'Pros & Cons',
        };
      default:
        return {
          bg: 'bg-slate-50 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-200',
          badge: 'bg-slate-700 text-white',
          label: 'Exam Fact',
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero Overview Card */}
      <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-blue-950 text-white rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-6 -mr-6 w-48 h-48 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 backdrop-blur-sm text-xs font-medium text-indigo-200">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Target Duration: <strong>{summary.estimatedReadTime || '5 Minutes'}</strong></span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopySummary}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-medium text-white transition"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Summary'}</span>
              </button>
            </div>
          </div>

          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              {summary.topicTitle}
            </h1>
            <p className="mt-2 text-sm sm:text-base text-slate-300 leading-relaxed max-w-4xl">
              {summary.overview}
            </p>
          </div>

          {/* 60-Second Speed Blitz Bar */}
          {summary.speedRevisionPoints && summary.speedRevisionPoints.length > 0 && (
            <div className="mt-4 pt-4 border-t border-white/15 bg-white/5 -mx-6 -mb-6 p-6 rounded-b-2xl">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-300 mb-2">
                <Zap className="w-4 h-4 fill-amber-300" />
                <span>60-Second Flash Recall (Read in 1 Minute)</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-slate-200">
                {summary.speedRevisionPoints.map((point, idx) => (
                  <div key={idx} className="flex items-start gap-2 bg-black/20 p-2 rounded-lg border border-white/5">
                    <span className="w-4 h-4 rounded-full bg-amber-400/20 text-amber-300 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span className="leading-snug">{point}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Filter Chips for Highlights */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-400">
          <Filter className="w-3.5 h-3.5" />
          <span>Highlight Focus:</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {filterTypes.map((ft) => (
            <button
              key={ft.id}
              onClick={() => setActiveHighlightFilter(ft.id)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition cursor-pointer ${
                activeHighlightFilter === ft.id
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              {ft.label}
            </button>
          ))}
        </div>
      </div>

      {/* Summary Sections */}
      <div className="space-y-6">
        {summary.sections.map((section, sIndex) => {
          const filteredHighlights = (section.highlights || []).filter((h) => {
            if (activeHighlightFilter === 'all') return true;
            return h.type === activeHighlightFilter;
          });

          return (
            <div
              key={sIndex}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 shadow-sm hover:border-indigo-300 dark:hover:border-indigo-800 transition"
            >
              {/* Section Header */}
              <div className="flex items-start justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                    {section.heading}
                  </h2>
                  <p className="text-xs text-indigo-600 dark:text-indigo-400 font-medium mt-0.5">
                    <strong>Core Takeaway:</strong> {section.keyTakeaway}
                  </p>
                </div>
                <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">
                  Part {sIndex + 1}
                </span>
              </div>

              {/* Bullet Points */}
              <ul className="space-y-2.5 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                {section.bulletPoints.map((bullet, bIndex) => (
                  <li key={bIndex} className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>

              {/* Highlight callout cards (definitions, formulas, comparisons) */}
              {filteredHighlights.length > 0 && (
                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 space-y-2">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    High-Yield Exam Focus
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {filteredHighlights.map((hl, hlIdx) => {
                      const styling = getHighlightBadge(hl);
                      return (
                        <div
                          key={hlIdx}
                          className={`p-3 rounded-lg border text-xs ${styling.bg} flex flex-col justify-between`}
                        >
                          <div className="flex items-center justify-between gap-2 mb-1.5">
                            <span className="font-bold text-slate-900 dark:text-white">{hl.label}</span>
                            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${styling.badge}`}>
                              {styling.label}
                            </span>
                          </div>
                          <p className="leading-snug opacity-95">{hl.text}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Bottom Quick Jump Action */}
      <div className="bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="text-xs text-slate-600 dark:text-slate-400">
          Done reviewing the 5-minute summary? Test your mastery with the exam components:
        </div>
        <div className="flex items-center gap-2">
          {onGoToMustRemember && (
            <button
              onClick={onGoToMustRemember}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-xs font-semibold shadow-sm transition"
            >
              Review Must Remember (Sec 2)
            </button>
          )}
          {onGoToMCQs && (
            <button
              onClick={onGoToMCQs}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-sm transition"
            >
              Take 20-MCQ Exam (Sec 3)
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
