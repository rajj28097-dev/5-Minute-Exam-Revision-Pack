import React, { useState } from 'react';
import {
  CheckCheck,
  Copy,
  Check,
  HelpCircle,
  Search,
  Filter,
  ArrowRight
} from 'lucide-react';
import { AnswerKeyEntry, MCQItem } from '../types/revision';

interface AnswerKeyViewProps {
  answerKey: AnswerKeyEntry[];
  shortExplanations: { questionNumber: number; correctOption: 'A' | 'B' | 'C' | 'D'; explanation: string }[];
  mcqs: MCQItem[];
}

export const AnswerKeyView: React.FC<AnswerKeyViewProps> = ({
  answerKey,
  shortExplanations,
  mcqs,
}) => {
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Formatted exact Answer Key string: 1. A, 2. C, 3. B...
  const formattedAnswerKeyText = answerKey
    .map((item) => `${item.questionNumber}. ${item.correctOption}`)
    .join('\n');

  const formattedAllText = [
    '=== 4. ANSWER KEY ===',
    formattedAnswerKeyText,
    '',
    '=== 5. SHORT EXPLANATIONS ===',
    ...shortExplanations.map((exp) => {
      const q = mcqs.find((m) => m.questionNumber === exp.questionNumber);
      return `Q${exp.questionNumber}. Correct: [${exp.correctOption}]\nQuestion: ${q?.question || ''}\nExplanation: ${exp.explanation}\n`;
    }),
  ].join('\n');

  const handleCopyKeyOnly = () => {
    navigator.clipboard.writeText(formattedAnswerKeyText);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleCopyAll = () => {
    navigator.clipboard.writeText(formattedAllText);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  const filteredExplanations = shortExplanations.filter((item) => {
    const q = mcqs.find((m) => m.questionNumber === item.questionNumber);
    if (!searchQuery) return true;
    const qText = (q?.question || '').toLowerCase();
    const expText = item.explanation.toLowerCase();
    const query = searchQuery.toLowerCase();
    return qText.includes(query) || expText.includes(query) || item.questionNumber.toString() === query;
  });

  return (
    <div className="space-y-8">
      {/* Section 4: Answer Key */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500 text-white flex items-center justify-center font-bold shadow-md shadow-emerald-500/20">
              <CheckCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                  4. Answer Key
                </h2>
                <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                  All 20 Questions
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Official key for university-level MCQs in standard format.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyKeyOnly}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-semibold transition"
            >
              {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedKey ? 'Key Copied' : 'Copy Key Only'}</span>
            </button>
            <button
              onClick={handleCopyAll}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-sm transition"
            >
              {copiedAll ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedAll ? 'Copied Everything' : 'Copy Key + Explanations'}</span>
            </button>
          </div>
        </div>

        {/* 20 Question Answer Grid */}
        <div>
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
            Quick Check Grid (Questions 1 - 20):
          </div>
          <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-10 gap-2">
            {answerKey.map((item) => (
              <div
                key={item.questionNumber}
                className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-center flex flex-col items-center justify-center hover:border-emerald-400 transition"
              >
                <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                  Q{item.questionNumber}
                </span>
                <span className="text-base font-black text-emerald-600 dark:text-emerald-400 mt-0.5">
                  {item.correctOption}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Exact Requested Formatted Text Box */}
        <div className="bg-slate-900 text-slate-100 rounded-xl p-4 font-mono text-xs overflow-x-auto border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-[11px] pb-2 border-b border-slate-800 mb-2">
            <span>Plain-Text Answer Key (1. A, 2. C, 3. B format):</span>
            <span className="text-emerald-400">Exact requested specification</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-y-1.5 gap-x-4">
            {answerKey.map((item) => (
              <div key={item.questionNumber} className="flex items-center gap-1.5">
                <span className="text-slate-400">{item.questionNumber}.</span>
                <span className="font-bold text-emerald-400">{item.correctOption}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Section 5: Short Explanations */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow-md shadow-indigo-600/20">
              <HelpCircle className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                  5. Short Explanations
                </h2>
                <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-800">
                  1–2 Line Rationale
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Concise justifications and trap clarifications for each MCQ answer.
              </p>
            </div>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by question / keyword..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* List of Explanations */}
        <div className="space-y-3">
          {filteredExplanations.map((exp) => {
            const questionData = mcqs.find((m) => m.questionNumber === exp.questionNumber);

            return (
              <div
                key={exp.questionNumber}
                className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900 hover:border-indigo-300 dark:hover:border-indigo-800 transition space-y-2"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                      {exp.questionNumber}
                    </span>
                    <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-300 dark:border-emerald-800">
                      Option {exp.correctOption}
                    </span>
                    {questionData?.type && (
                      <span className="text-[10px] text-slate-400 font-medium px-2 py-0.5 rounded bg-slate-200/60 dark:bg-slate-800">
                        {questionData.type}
                      </span>
                    )}
                  </div>
                </div>

                {questionData && (
                  <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    {questionData.question}
                  </p>
                )}

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-white dark:bg-slate-800/80 p-2.5 rounded-lg border border-slate-200/70 dark:border-slate-700">
                  <strong className="text-slate-900 dark:text-white">Explanation: </strong>
                  {exp.explanation}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
