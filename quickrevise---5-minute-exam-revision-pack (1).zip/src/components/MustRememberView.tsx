import React, { useState } from 'react';
import {
  Flame,
  Bookmark,
  CheckCircle,
  AlertTriangle,
  Lightbulb,
  Copy,
  Check,
  Tag,
  Star
} from 'lucide-react';
import { MustRememberPoint } from '../types/revision';

interface MustRememberViewProps {
  points: MustRememberPoint[];
}

export const MustRememberView: React.FC<MustRememberViewProps> = ({ points }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [memorizedIds, setMemorizedIds] = useState<Set<number>>(new Set());
  const [copied, setCopied] = useState(false);

  const categories = [
    'all',
    'Core Formula/Rule',
    'Vital Definition',
    'Crucial Distinction',
    'Frequent Exam Trap',
    'High-Yield Fact'
  ];

  const filteredPoints = points.filter((p) => {
    if (selectedCategory === 'all') return true;
    return p.category === selectedCategory;
  });

  const toggleMemorized = (id: number) => {
    setMemorizedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleCopyAll = () => {
    const text = [
      '# MUST REMEMBER - HIGH-YIELD EXAM POINTS',
      '',
      ...points.map(
        (p, i) => `${i + 1}. [${p.category}] ${p.point}\n   Why Exam-Relevant: ${p.whyImportant}\n`
      ),
    ].join('\n');

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getCategoryTheme = (category: string) => {
    switch (category) {
      case 'Core Formula/Rule':
        return {
          border: 'border-amber-400 dark:border-amber-600',
          badge: 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200 border-amber-300 dark:border-amber-800',
          icon: <Flame className="w-4 h-4 text-amber-500" />
        };
      case 'Frequent Exam Trap':
        return {
          border: 'border-rose-400 dark:border-rose-600',
          badge: 'bg-rose-100 text-rose-900 dark:bg-rose-950 dark:text-rose-200 border-rose-300 dark:border-rose-800',
          icon: <AlertTriangle className="w-4 h-4 text-rose-500" />
        };
      case 'Crucial Distinction':
        return {
          border: 'border-purple-400 dark:border-purple-600',
          badge: 'bg-purple-100 text-purple-900 dark:bg-purple-950 dark:text-purple-200 border-purple-300 dark:border-purple-800',
          icon: <Lightbulb className="w-4 h-4 text-purple-500" />
        };
      case 'Vital Definition':
        return {
          border: 'border-blue-400 dark:border-blue-600',
          badge: 'bg-blue-100 text-blue-900 dark:bg-blue-950 dark:text-blue-200 border-blue-300 dark:border-blue-800',
          icon: <Bookmark className="w-4 h-4 text-blue-500" />
        };
      default:
        return {
          border: 'border-emerald-400 dark:border-emerald-600',
          badge: 'bg-emerald-100 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-200 border-emerald-300 dark:border-emerald-800',
          icon: <Star className="w-4 h-4 text-emerald-500" />
        };
    }
  };

  const memorizedCount = memorizedIds.size;
  const progressPercent = points.length > 0 ? (memorizedCount / points.length) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-amber-500/5 border border-amber-500/30 rounded-2xl p-6 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-md shadow-amber-500/20">
              <Flame className="w-6 h-6 fill-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                  Must Remember
                </h2>
                <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500 text-white">
                  High-Yield Exam Vault
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1">
                The non-negotiable points most likely to decide marks in your exam. Check them off as you lock them into memory.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Memory progress */}
            <div className="bg-white dark:bg-slate-900 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs">
              <div className="flex items-center justify-between gap-2 font-medium mb-1">
                <span className="text-slate-500">Memorized:</span>
                <span className="font-bold text-amber-600 dark:text-amber-400">
                  {memorizedCount} / {points.length}
                </span>
              </div>
              <div className="w-28 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            <button
              onClick={handleCopyAll}
              className="flex items-center gap-1.5 px-3 py-2 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 transition"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied' : 'Copy All'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-3">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition cursor-pointer ${
              selectedCategory === cat
                ? 'bg-amber-500 text-white font-semibold shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300'
            }`}
          >
            {cat === 'all' ? 'All Points' : cat}
          </button>
        ))}
      </div>

      {/* Must Remember Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredPoints.map((item, idx) => {
          const isMemorized = memorizedIds.has(item.id || idx);
          const theme = getCategoryTheme(item.category);

          return (
            <div
              key={item.id || idx}
              onClick={() => toggleMemorized(item.id || idx)}
              className={`p-5 rounded-2xl border transition-all cursor-pointer select-none flex flex-col justify-between ${
                isMemorized
                  ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800 opacity-80'
                  : 'bg-white dark:bg-slate-900 hover:shadow-md hover:border-amber-400 dark:hover:border-amber-600 border-slate-200 dark:border-slate-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-1.5">
                    {theme.icon}
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${theme.badge}`}>
                      {item.category}
                    </span>
                    {item.tag && (
                      <span className="text-[11px] text-slate-400 flex items-center gap-0.5">
                        <Tag className="w-3 h-3" />
                        {item.tag}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 text-xs">
                    <span
                      className={`w-5 h-5 rounded-md flex items-center justify-center border transition ${
                        isMemorized
                          ? 'bg-emerald-500 border-emerald-500 text-white'
                          : 'border-slate-300 dark:border-slate-700 text-transparent'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </span>
                  </div>
                </div>

                <p className={`text-sm sm:text-base font-semibold leading-snug mb-3 ${
                  isMemorized
                    ? 'line-through text-slate-500 dark:text-slate-400'
                    : 'text-slate-900 dark:text-white'
                }`}>
                  {item.point}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80">
                <div className="flex items-start gap-1.5 text-xs text-amber-700 dark:text-amber-300 bg-amber-500/10 p-2 rounded-lg">
                  <Lightbulb className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                  <span className="leading-snug">
                    <strong className="font-semibold">Why Tested in Exam:</strong> {item.whyImportant}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
