import React, { useState, useEffect } from 'react';
import { Timer, Play, Pause, RotateCcw, BellRing } from 'lucide-react';

interface CramTimerProps {
  initialSeconds?: number;
}

export const CramTimer: React.FC<CramTimerProps> = ({ initialSeconds = 300 }) => {
  const [timeLeft, setTimeLeft] = useState(initialSeconds);
  const [isRunning, setIsRunning] = useState(false);
  const [hasFinished, setHasFinished] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      setIsRunning(false);
      setHasFinished(true);
      // Play web audio chime if supported
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
        gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 1.2);
        osc.start();
        osc.stop(audioCtx.currentTime + 1.2);
      } catch (e) {
        console.log('Audio chime not available', e);
      }
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, timeLeft]);

  const toggleRun = () => {
    if (timeLeft === 0) {
      setTimeLeft(initialSeconds);
      setHasFinished(false);
    }
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(initialSeconds);
    setHasFinished(false);
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const progressPercent = ((initialSeconds - timeLeft) / initialSeconds) * 100;

  return (
    <div className="flex items-center gap-3 bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-full text-xs font-medium text-amber-900 dark:text-amber-200">
      <div className="flex items-center gap-1.5">
        <Timer className={`w-4 h-4 text-amber-600 dark:text-amber-400 ${isRunning ? 'animate-pulse' : ''}`} />
        <span className="font-semibold text-xs tracking-wider uppercase text-amber-700 dark:text-amber-300">
          5-Min Cram:
        </span>
        <span className={`font-mono text-sm font-bold ${timeLeft <= 60 ? 'text-red-500 animate-pulse' : 'text-slate-800 dark:text-slate-100'}`}>
          {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
        </span>
      </div>

      <div className="w-14 h-1.5 bg-amber-200/50 dark:bg-amber-950 rounded-full overflow-hidden hidden sm:block">
        <div
          className={`h-full transition-all duration-500 ${timeLeft <= 60 ? 'bg-red-500' : 'bg-amber-500'}`}
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      <div className="flex items-center gap-1">
        <button
          onClick={toggleRun}
          title={isRunning ? 'Pause Timer' : 'Start 5-Minute Cram Timer'}
          className="p-1 hover:bg-amber-200/50 dark:hover:bg-amber-900/50 rounded-full transition text-amber-800 dark:text-amber-200"
        >
          {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
        </button>
        <button
          onClick={resetTimer}
          title="Reset to 5:00"
          className="p-1 hover:bg-amber-200/50 dark:hover:bg-amber-900/50 rounded-full transition text-amber-700 dark:text-amber-300"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {hasFinished && (
        <span className="flex items-center gap-1 text-red-500 font-bold animate-bounce text-[11px]">
          <BellRing className="w-3 h-3" /> Time Up!
        </span>
      )}
    </div>
  );
};
