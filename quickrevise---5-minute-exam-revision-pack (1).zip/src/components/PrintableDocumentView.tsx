import React from 'react';
import { RevisionPack } from '../types/revision';
import { Printer, Download, ArrowLeft } from 'lucide-react';

interface PrintableDocumentViewProps {
  pack: RevisionPack;
  onBackToApp: () => void;
}

export const PrintableDocumentView: React.FC<PrintableDocumentViewProps> = ({
  pack,
  onBackToApp,
}) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-slate-100 dark:bg-slate-950 min-h-screen py-8 px-4 sm:px-6">
      {/* Non-printed action bar */}
      <div className="max-w-4xl mx-auto mb-6 flex items-center justify-between print:hidden">
        <button
          onClick={onBackToApp}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> Back to Interactive View
        </button>

        <button
          onClick={handlePrint}
          className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold shadow-md transition"
        >
          <Printer className="w-4 h-4" /> Print / Save as PDF
        </button>
      </div>

      {/* Printable Sheet */}
      <div className="max-w-4xl mx-auto bg-white text-slate-900 p-8 sm:p-12 rounded-2xl shadow-xl print:shadow-none print:p-0 print:m-0 print:max-w-none text-sm leading-relaxed border border-slate-200 print:border-none font-sans">
        {/* Document Header */}
        <div className="border-b-2 border-slate-900 pb-4 mb-6">
          <div className="flex items-center justify-between text-xs text-slate-500 uppercase font-mono tracking-wider mb-1">
            <span>5-Minute University Exam Revision Pack</span>
            <span>Est. Revision Time: {pack.quickSummary.estimatedReadTime || '5 Minutes'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            {pack.title}
          </h1>
          <p className="text-xs text-slate-600 mt-1 italic">
            Source Scope: {pack.sourceNoteSummary}
          </p>
        </div>

        {/* 1. 5-Minute Quick Summary */}
        <section className="mb-8 page-break-after-auto">
          <div className="flex items-center gap-2 border-b border-slate-300 pb-1 mb-3">
            <h2 className="text-lg font-bold text-slate-900 uppercase tracking-wide">
              1. 5-Minute Quick Summary
            </h2>
          </div>
          <p className="text-xs text-slate-700 mb-4 font-serif leading-relaxed">
            {pack.quickSummary.overview}
          </p>

          {/* 60s speed points */}
          {pack.quickSummary.speedRevisionPoints && (
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 mb-4 text-xs">
              <strong className="font-bold text-slate-900 block mb-1">60-Second Flash Recall:</strong>
              <ul className="list-disc pl-5 space-y-0.5">
                {pack.quickSummary.speedRevisionPoints.map((pt, i) => (
                  <li key={i}>{pt}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Sections */}
          <div className="space-y-4">
            {pack.quickSummary.sections.map((sec, idx) => (
              <div key={idx} className="space-y-1">
                <h3 className="text-xs font-bold text-slate-900 underline decoration-slate-300">
                  {sec.heading}
                </h3>
                <ul className="list-disc pl-5 space-y-1 text-xs text-slate-800">
                  {sec.bulletPoints.map((b, bIdx) => (
                    <li key={bIdx}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>

        {/* 2. Important Exam Points ("Must Remember") */}
        <section className="mb-8">
          <div className="flex items-center gap-2 border-b border-slate-300 pb-1 mb-3">
            <h2 className="text-lg font-bold text-slate-900 uppercase tracking-wide">
              2. Important Exam Points ("Must Remember")
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {pack.mustRemember.map((item, idx) => (
              <div key={idx} className="p-3 border border-slate-200 rounded-lg bg-slate-50/50">
                <div className="font-bold text-slate-900 mb-1">
                  #{idx + 1} [{item.category}]: {item.point}
                </div>
                <div className="text-[11px] text-slate-600 italic">
                  Why Tested: {item.whyImportant}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 3. Exam-Level MCQs (20 Questions) */}
        <section className="mb-8">
          <div className="flex items-center gap-2 border-b border-slate-300 pb-1 mb-4">
            <h2 className="text-lg font-bold text-slate-900 uppercase tracking-wide">
              3. Exam-Level MCQs (20 Questions)
            </h2>
          </div>
          <div className="space-y-4 text-xs">
            {pack.mcqs.map((m) => (
              <div key={m.questionNumber} className="border-b border-slate-100 pb-3">
                <div className="font-bold text-slate-900 mb-1.5">
                  Q{m.questionNumber}. {m.question}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1 text-slate-800">
                  <div><strong>(A)</strong> {m.options.A}</div>
                  <div><strong>(B)</strong> {m.options.B}</div>
                  <div><strong>(C)</strong> {m.options.C}</div>
                  <div><strong>(D)</strong> {m.options.D}</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 4. Answer Key */}
        <section className="mb-8">
          <div className="flex items-center gap-2 border-b border-slate-300 pb-1 mb-3">
            <h2 className="text-lg font-bold text-slate-900 uppercase tracking-wide">
              4. Answer Key
            </h2>
          </div>
          <div className="grid grid-cols-5 sm:grid-cols-10 gap-2 text-xs font-mono text-center">
            {pack.answerKey.map((k) => (
              <div key={k.questionNumber} className="border border-slate-300 p-1.5 rounded">
                <span className="text-slate-500 block text-[10px]">Q{k.questionNumber}</span>
                <span className="font-bold text-slate-900 text-sm">{k.correctOption}</span>
              </div>
            ))}
          </div>
        </section>

        {/* 5. Short Explanations */}
        <section className="mb-8">
          <div className="flex items-center gap-2 border-b border-slate-300 pb-1 mb-3">
            <h2 className="text-lg font-bold text-slate-900 uppercase tracking-wide">
              5. Short Explanations
            </h2>
          </div>
          <div className="space-y-2 text-xs">
            {pack.shortExplanations.map((exp) => (
              <div key={exp.questionNumber} className="flex items-start gap-2">
                <span className="font-bold font-mono text-slate-900 shrink-0">
                  Q{exp.questionNumber} [{exp.correctOption}]:
                </span>
                <span className="text-slate-700">{exp.explanation}</span>
              </div>
            ))}
          </div>
        </section>

        {/* 6. Exam Practice */}
        <section className="mb-8">
          <div className="flex items-center gap-2 border-b border-slate-300 pb-1 mb-4">
            <h2 className="text-lg font-bold text-slate-900 uppercase tracking-wide">
              6. Exam Practice (VIQs, Short & Long)
            </h2>
          </div>

          <div className="space-y-6 text-xs">
            {/* 5 VIQ */}
            <div>
              <h3 className="font-bold text-slate-900 text-sm uppercase mb-2">
                5 Very Important Questions (VIQs):
              </h3>
              <div className="space-y-3 pl-2">
                {pack.examPractice.veryImportantQuestions.map((q, i) => (
                  <div key={i} className="border-l-2 border-slate-300 pl-3 space-y-1">
                    <div className="font-bold text-slate-900">
                      VIQ {i + 1} ({q.weightage || '5 Marks'}): {q.question}
                    </div>
                    <div className="text-slate-700 italic">
                      Model Answer: {q.modelAnswer}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 5 Short */}
            <div>
              <h3 className="font-bold text-slate-900 text-sm uppercase mb-2">
                5 Short-Answer Questions:
              </h3>
              <div className="space-y-2 pl-2">
                {pack.examPractice.shortAnswerQuestions.map((q, i) => (
                  <div key={i} className="space-y-0.5">
                    <div className="font-bold text-slate-900">
                      SA {i + 1} ({q.weightage || '2-3 Marks'}): {q.question}
                    </div>
                    <div className="text-slate-700 pl-3">
                      {q.modelAnswer}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 3 Long */}
            <div>
              <h3 className="font-bold text-slate-900 text-sm uppercase mb-2">
                3 Long-Answer Questions:
              </h3>
              <div className="space-y-3 pl-2">
                {pack.examPractice.longAnswerQuestions.map((q, i) => (
                  <div key={i} className="border-l-2 border-indigo-400 pl-3 space-y-1">
                    <div className="font-bold text-slate-900">
                      LA {i + 1} ({q.weightage || '10 Marks'}): {q.question}
                    </div>
                    <div className="text-slate-800 whitespace-pre-line">
                      {q.modelAnswer}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
