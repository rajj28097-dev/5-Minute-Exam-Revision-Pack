import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  CheckCircle,
  XCircle,
  HelpCircle,
  RotateCcw,
  Trophy,
  Filter,
  Eye,
  EyeOff,
  ChevronLeft,
  ChevronRight,
  ListFilter,
  Sparkles
} from 'lucide-react';
import { MCQItem } from '../types/revision';

interface MCQExamViewProps {
  mcqs: MCQItem[];
  onViewAnswerKey?: () => void;
}

export const MCQExamView: React.FC<MCQExamViewProps> = ({ mcqs, onViewAnswerKey }) => {
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, 'A' | 'B' | 'C' | 'D'>>({});
  const [examSubmitted, setExamSubmitted] = useState<boolean>(false);
  const [isInstantFeedback, setIsInstantFeedback] = useState<boolean>(true);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [viewLayout, setViewLayout] = useState<'card' | 'all'>('card');
  const [filterType, setFilterType] = useState<string>('all');
  const [revealedExplanations, setRevealedExplanations] = useState<Set<number>>(new Set());

  const filteredMCQs = mcqs.filter((m) => {
    if (filterType === 'all') return true;
    return m.type === filterType;
  });

  const currentMCQ = filteredMCQs[currentQuestionIndex] || filteredMCQs[0] || mcqs[0];

  const handleSelectOption = (qNumber: number, optionKey: 'A' | 'B' | 'C' | 'D') => {
    if (examSubmitted) return;
    setSelectedAnswers((prev) => ({
      ...prev,
      [qNumber]: optionKey,
    }));
  };

  const toggleExplanation = (qNum: number) => {
    setRevealedExplanations((prev) => {
      const next = new Set(prev);
      if (next.has(qNum)) next.delete(qNum);
      else next.add(qNum);
      return next;
    });
  };

  const calculateScore = () => {
    let score = 0;
    mcqs.forEach((m) => {
      if (selectedAnswers[m.questionNumber] === m.correctOption) {
        score += 1;
      }
    });
    return score;
  };

  const handleSubmitExam = () => {
    setExamSubmitted(true);
    const score = calculateScore();
    const percent = (score / mcqs.length) * 100;
    if (percent >= 70) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {
        console.log(e);
      }
    }
  };

  const handleResetExam = () => {
    setSelectedAnswers({});
    setExamSubmitted(false);
    setRevealedExplanations(new Set());
    setCurrentQuestionIndex(0);
  };

  const totalAnswered = Object.keys(selectedAnswers).length;
  const score = calculateScore();
  const percentage = Math.round((score / mcqs.length) * 100);

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'tricky':
        return 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border-rose-300';
      case 'application-based':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border-amber-300';
      case 'difference-based':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 border-purple-300';
      case 'definition-based':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 border-blue-300';
      case 'factual':
        return 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 border-teal-300';
      default:
        return 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Controls Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
                20 Exam-Level MCQs
              </h2>
              <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-600 text-white">
                University Level
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Strictly derived from your notes. Mixture of tricky, concept, definition, difference, and application questions.
            </p>
          </div>

          {/* Action buttons & mode toggle */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs">
              <button
                onClick={() => setViewLayout('card')}
                className={`px-2.5 py-1 rounded-md font-medium transition ${
                  viewLayout === 'card'
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-white shadow-xs font-semibold'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                1 by 1 Focus
              </button>
              <button
                onClick={() => setViewLayout('all')}
                className={`px-2.5 py-1 rounded-md font-medium transition ${
                  viewLayout === 'all'
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-white shadow-xs font-semibold'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                All 20 Grid
              </button>
            </div>

            <button
              onClick={() => setIsInstantFeedback(!isInstantFeedback)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition cursor-pointer ${
                isInstantFeedback
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800 dark:bg-emerald-950 dark:border-emerald-800 dark:text-emerald-200'
                  : 'bg-slate-50 border-slate-300 text-slate-700 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300'
              }`}
            >
              {isInstantFeedback ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              <span>{isInstantFeedback ? 'Instant Feedback: ON' : 'Exam Mode: OFF'}</span>
            </button>

            {totalAnswered > 0 && (
              <button
                onClick={handleResetExam}
                className="flex items-center gap-1 p-2 text-slate-500 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-xs transition"
                title="Reset Answers"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* 1-20 Number Navigator Grid */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span>Quick Navigation (1 to 20):</span>
            <span>
              Attempted: <strong>{totalAnswered} / {mcqs.length}</strong>
            </span>
          </div>
          <div className="grid grid-cols-10 sm:grid-cols-20 gap-1 sm:gap-1.5">
            {mcqs.map((m, index) => {
              const isSelected = selectedAnswers[m.questionNumber] !== undefined;
              const isCorrect = selectedAnswers[m.questionNumber] === m.correctOption;
              const isCurrent = viewLayout === 'card' && currentMCQ?.questionNumber === m.questionNumber;

              let btnStyle = 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300';
              if (examSubmitted || (isInstantFeedback && isSelected)) {
                btnStyle = isCorrect
                  ? 'bg-emerald-500 text-white font-bold'
                  : 'bg-rose-500 text-white font-bold';
              } else if (isSelected) {
                btnStyle = 'bg-indigo-600 text-white font-bold';
              }

              return (
                <button
                  key={m.questionNumber}
                  onClick={() => {
                    if (viewLayout === 'card') {
                      setCurrentQuestionIndex(index);
                    } else {
                      const el = document.getElementById(`mcq-${m.questionNumber}`);
                      el?.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className={`h-7 rounded-md text-xs font-semibold flex items-center justify-center transition border ${
                    isCurrent
                      ? 'ring-2 ring-indigo-500 ring-offset-2 dark:ring-offset-slate-900 border-indigo-600'
                      : 'border-transparent hover:border-slate-300 dark:hover:border-slate-600'
                  } ${btnStyle}`}
                >
                  {m.questionNumber}
                </button>
              );
            })}
          </div>
        </div>

        {/* Score banner if submitted */}
        {examSubmitted && (
          <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-indigo-500/10 border border-indigo-500/30 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
                <Trophy className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <div className="font-extrabold text-base text-slate-900 dark:text-white">
                  Score: {score} / {mcqs.length} ({percentage}%)
                </div>
                <div className="text-xs text-slate-500">
                  {percentage >= 80
                    ? 'Outstanding! You are fully prepped for the exam!'
                    : percentage >= 60
                    ? 'Good job! Review the short explanations to lock in tricky points.'
                    : 'Time for a 5-minute recap of the Quick Summary and Must Remember.'}
                </div>
              </div>
            </div>

            {onViewAnswerKey && (
              <button
                onClick={onViewAnswerKey}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-sm transition"
              >
                View Full Answer Key
              </button>
            )}
          </div>
        )}
      </div>

      {/* Single Card Focus Mode */}
      {viewLayout === 'card' && currentMCQ && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-sm space-y-6">
          <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-sm">
                Q{currentMCQ.questionNumber}
              </span>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${getTypeBadge(currentMCQ.type)}`}>
                {currentMCQ.type}
              </span>
            </div>
            <span className="text-xs text-slate-400 font-medium">
              Question {currentQuestionIndex + 1} of {filteredMCQs.length}
            </span>
          </div>

          <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-relaxed">
            {currentMCQ.question}
          </h3>

          {/* Options */}
          <div className="space-y-3">
            {(['A', 'B', 'C', 'D'] as const).map((optKey) => {
              const optionText = currentMCQ.options[optKey];
              const isSelected = selectedAnswers[currentMCQ.questionNumber] === optKey;
              const isCorrectAnswer = currentMCQ.correctOption === optKey;
              const showResult = examSubmitted || (isInstantFeedback && selectedAnswers[currentMCQ.questionNumber] !== undefined);

              let optionStyle = 'border-slate-200 dark:border-slate-700 hover:border-indigo-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-800 dark:text-slate-200';
              let badgeStyle = 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300';

              if (showResult) {
                if (isCorrectAnswer) {
                  optionStyle = 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 font-semibold ring-1 ring-emerald-500';
                  badgeStyle = 'bg-emerald-600 text-white';
                } else if (isSelected && !isCorrectAnswer) {
                  optionStyle = 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-900 dark:text-rose-200 ring-1 ring-rose-500';
                  badgeStyle = 'bg-rose-600 text-white';
                }
              } else if (isSelected) {
                optionStyle = 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200 font-semibold ring-1 ring-indigo-600';
                badgeStyle = 'bg-indigo-600 text-white';
              }

              return (
                <button
                  key={optKey}
                  onClick={() => handleSelectOption(currentMCQ.questionNumber, optKey)}
                  className={`w-full text-left p-4 rounded-xl border flex items-start gap-3 transition cursor-pointer ${optionStyle}`}
                >
                  <span className={`w-6 h-6 rounded-md flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${badgeStyle}`}>
                    {optKey}
                  </span>
                  <span className="text-sm leading-relaxed grow">{optionText}</span>
                  {showResult && isCorrectAnswer && (
                    <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                  )}
                  {showResult && isSelected && !isCorrectAnswer && (
                    <XCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation if shown */}
          {(examSubmitted || (isInstantFeedback && selectedAnswers[currentMCQ.questionNumber] !== undefined)) && (
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 text-xs space-y-1.5 animate-fadeIn">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <HelpCircle className="w-4 h-4 text-indigo-500" />
                  Explanation & University Insight:
                </span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">
                  Correct Answer: Option {currentMCQ.correctOption}
                </span>
              </div>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                {currentMCQ.explanation}
              </p>
            </div>
          )}

          {/* Prev / Next Controls */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => setCurrentQuestionIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentQuestionIndex === 0}
              className="flex items-center gap-1 px-4 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 disabled:opacity-40 transition"
            >
              <ChevronLeft className="w-4 h-4" /> Previous
            </button>

            {!examSubmitted ? (
              <button
                onClick={handleSubmitExam}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 active:scale-95 shadow-md shadow-indigo-600/20 transition cursor-pointer"
              >
                Submit Exam ({totalAnswered}/20 Done)
              </button>
            ) : (
              <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                Exam Completed
              </span>
            )}

            <button
              onClick={() => setCurrentQuestionIndex((prev) => Math.min(filteredMCQs.length - 1, prev + 1))}
              disabled={currentQuestionIndex === filteredMCQs.length - 1}
              className="flex items-center gap-1 px-4 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 disabled:opacity-40 transition"
            >
              Next <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* All 20 Grid Mode */}
      {viewLayout === 'all' && (
        <div className="space-y-5">
          {filteredMCQs.map((m) => {
            const isSelected = selectedAnswers[m.questionNumber] !== undefined;
            const isRevealed = revealedExplanations.has(m.questionNumber) || examSubmitted || (isInstantFeedback && isSelected);

            return (
              <div
                id={`mcq-${m.questionNumber}`}
                key={m.questionNumber}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 shadow-sm space-y-4"
              >
                <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-md bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                      {m.questionNumber}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${getTypeBadge(m.type)}`}>
                      {m.type}
                    </span>
                  </div>
                  <button
                    onClick={() => toggleExplanation(m.questionNumber)}
                    className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                  >
                    {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{isRevealed ? 'Hide Explanation' : 'Show Explanation'}</span>
                  </button>
                </div>

                <p className="text-sm sm:text-base font-semibold text-slate-900 dark:text-white leading-relaxed">
                  {m.question}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {(['A', 'B', 'C', 'D'] as const).map((optKey) => {
                    const optionText = m.options[optKey];
                    const selected = selectedAnswers[m.questionNumber] === optKey;
                    const isCorrect = m.correctOption === optKey;
                    const showResult = isRevealed && isSelected;

                    let optStyle = 'border-slate-200 dark:border-slate-700 hover:border-indigo-400 text-slate-800 dark:text-slate-200';
                    let keyBadge = 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300';

                    if (showResult) {
                      if (isCorrect) {
                        optStyle = 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 font-semibold';
                        keyBadge = 'bg-emerald-600 text-white';
                      } else if (selected && !isCorrect) {
                        optStyle = 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-900 dark:text-rose-200';
                        keyBadge = 'bg-rose-600 text-white';
                      }
                    } else if (selected) {
                      optStyle = 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200 font-semibold';
                      keyBadge = 'bg-indigo-600 text-white';
                    }

                    return (
                      <button
                        key={optKey}
                        onClick={() => handleSelectOption(m.questionNumber, optKey)}
                        className={`text-left p-3 rounded-lg border flex items-start gap-2.5 transition cursor-pointer text-xs ${optStyle}`}
                      >
                        <span className={`w-5 h-5 rounded flex items-center justify-center font-bold shrink-0 mt-0.5 ${keyBadge}`}>
                          {optKey}
                        </span>
                        <span className="leading-snug grow">{optionText}</span>
                      </button>
                    );
                  })}
                </div>

                {isRevealed && (
                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-xs">
                    <span className="font-bold text-emerald-600 dark:text-emerald-400">
                      Answer: Option {m.correctOption}
                    </span>
                    <p className="text-slate-600 dark:text-slate-300 mt-1">
                      {m.explanation}
                    </p>
                  </div>
                )}
              </div>
            );
          })}

          <div className="flex justify-center pt-4">
            <button
              onClick={handleSubmitExam}
              className="px-8 py-3 rounded-xl text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 active:scale-95 shadow-lg shadow-indigo-600/30 transition cursor-pointer"
            >
              Submit & Check All 20 MCQs
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
