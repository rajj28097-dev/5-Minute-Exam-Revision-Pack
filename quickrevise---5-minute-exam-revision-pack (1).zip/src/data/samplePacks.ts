import { RevisionPack } from '../types/revision';

export const SAMPLE_PACKS: RevisionPack[] = [
  {
    id: 'os-deadlocks-sync',
    title: 'Operating Systems: Process Synchronization & Deadlocks',
    sourceNoteSummary: 'Lecture notes covering Critical Section Problem, Peterson’s Solution, Semaphores (Counting & Binary), Mutex, Deadlock 4 Coffman Conditions, Resource Allocation Graphs, and Banker’s Algorithm.',
    generatedAt: new Date().toISOString(),
    quickSummary: {
      topicTitle: 'Process Synchronization & Deadlocks',
      estimatedReadTime: '4 mins 45 secs',
      overview: 'Process synchronization coordinates cooperating processes sharing a logical address space to maintain data consistency. When synchronization fails or resource allocation is unmanaged, circular dependencies cause deadlocks where processes remain blocked forever.',
      sections: [
        {
          heading: '1. Critical Section Problem & Criteria',
          keyTakeaway: 'The section of code accessing shared resources must be protected to prevent race conditions.',
          bulletPoints: [
            'Mutual Exclusion: If process Pi is executing in its critical section, no other processes can execute in their critical sections.',
            'Progress: If no process is in its critical section and some wish to enter, only those not in their remainder section can participate in deciding who enters next (no indefinite postponement).',
            'Bounded Waiting: A bound must exist on the number of times other processes are allowed to enter their critical sections after a process has made a request.',
            'Peterson’s Solution: Classic software solution for two processes using turn and flag[2] variables; guarantees all 3 criteria on single-core architecture.'
          ],
          highlights: [
            {
              label: 'Race Condition',
              type: 'definition',
              text: 'A situation where multiple threads/processes access and manipulate shared data concurrently and the outcome depends on the particular order of execution.'
            },
            {
              label: 'Mutex vs Semaphore',
              type: 'difference',
              text: 'Mutex is a locking mechanism with ownership (only locker can unlock); Semaphore is a signaling mechanism (wait/signal or P/V) that can be signaled by any thread.'
            }
          ]
        },
        {
          heading: '2. Semaphores & Synchronization Primitives',
          keyTakeaway: 'Atomic integer variables accessed exclusively through wait() [P] and signal() [V] primitives.',
          bulletPoints: [
            'Counting Semaphore: Integer value ranges over an unrestricted domain (used for managing finite instances of a resource).',
            'Binary Semaphore (Mutex-like): Value can range only between 0 and 1.',
            'Busy Waiting (Spinlock): Repeated testing of a condition in a loop without yielding CPU; wastes cycles unless wait durations are extremely short.',
            'Block & Wakeup: Overcomes spinlocks by putting the calling process into a sleep/waiting queue associated with the semaphore.'
          ],
          highlights: [
            {
              label: 'Classic Problems',
              type: 'fact',
              text: 'Producer-Consumer (bounded buffer), Readers-Writers (starvation risks), Dining Philosophers (deadlock risk if all pick left fork simultaneously).'
            }
          ]
        },
        {
          heading: '3. Deadlock Characterization (Coffman Conditions)',
          keyTakeaway: 'A deadlock can occur IF AND ONLY IF all four Coffman conditions hold simultaneously.',
          bulletPoints: [
            '1. Mutual Exclusion: At least one resource must be held in a non-shareable mode.',
            '2. Hold and Wait: A process must be holding at least one resource and waiting to acquire additional resources held by other processes.',
            '3. No Preemption: Resources cannot be preempted; a resource can be released only voluntarily by the holding process.',
            '4. Circular Wait: A closed chain of processes exists such that P0 waits for P1, P1 waits for P2, ..., Pn waits for P0.'
          ],
          highlights: [
            {
              label: 'Coffman Simultaneous Rule',
              type: 'fact',
              text: 'All four Coffman conditions must hold simultaneously for a deadlock to exist. Eliminating or invalidating even ONE condition guarantees deadlock prevention.'
            }
          ]
        },
        {
          heading: '4. Deadlock Handling Strategies',
          keyTakeaway: 'Four main approaches: Prevention (invalidate 1 condition), Avoidance (Banker\'s), Detection & Recovery, or Ignorance (Ostrich Algorithm).',
          bulletPoints: [
            'Deadlock Prevention: Enforce rules that negate at least one Coffman condition (e.g., impose total resource ordering to eliminate circular wait).',
            'Deadlock Avoidance: Requires dynamic knowledge of future requests (Safe vs Unsafe states; all deadlocks are unsafe, but not all unsafe states are deadlocked).',
            'Recovery: Process termination (abort all or one-by-one) or resource preemption (requires rollback and prevention of starvation).',
            'Ostrich Algorithm: Stick head in the sand; assume deadlocks never occur (used by Unix/Windows for performance tradeoffs).'
          ],
          highlights: [
            {
              label: 'Banker’s Algorithm Condition',
              type: 'formula',
              text: 'Need[i, j] = Max[i, j] - Allocation[i, j]. A state is SAFE if a sequence (P1, P2, ..., Pn) exists where each process satisfies Need[i] ≤ Work (where Work is initialized to Available, and updated as Work = Work + Allocation[i] after process completion).'
            }
          ]
        }
      ],
      speedRevisionPoints: [
        'Critical section requirements: Mutual Exclusion, Progress, Bounded Waiting.',
        'Semaphores: wait() decrements; signal() increments. Both MUST be atomic.',
        'Deadlock exists if and only if all 4 Coffman conditions hold simultaneously.',
        'Banker\'s Algorithm formula: Need = Max - Allocation.',
        'Safe state guarantees deadlock freedom; Unsafe state creates the potential for deadlock.'
      ]
    },
    mustRemember: [
      {
        id: 1,
        point: 'All deadlocks represent unsafe states, but an unsafe state does NOT guarantee a deadlock has occurred yet.',
        category: 'Crucial Distinction',
        tag: 'Avoidance vs Deadlock',
        whyImportant: 'Extremely popular trick question on university midterms and finals.'
      },
      {
        id: 2,
        point: 'Need[i][j] = Max[i][j] - Allocation[i][j]. For Banker\'s safe sequence verification, verify Need <= Available.',
        category: 'Core Formula/Rule',
        tag: 'Banker’s Algorithm',
        whyImportant: 'Direct numerical question worth 5 to 10 marks in standard university exam papers.'
      },
      {
        id: 3,
        point: 'Peterson\'s solution requires strictly TWO processes and assumes memory reads/writes are atomic without hardware instruction reordering.',
        category: 'Frequent Exam Trap',
        tag: 'Peterson’s Limitation',
        whyImportant: 'Modern superscalar CPUs reorder loads/stores, breaking naive Peterson implementations without memory barriers.'
      },
      {
        id: 4,
        point: 'To eliminate Circular Wait via prevention, establish a global numerical ordering of all resource types and enforce strictly monotonic allocation.',
        category: 'High-Yield Fact',
        tag: 'Havender’s Ordering',
        whyImportant: 'The single most practical deadlock prevention protocol adopted in production code.'
      },
      {
        id: 5,
        point: 'In Resource Allocation Graphs (RAG), a cycle is a NECESSARY and SUFFICIENT condition for deadlock ONLY if every resource type has exactly 1 instance.',
        category: 'Crucial Distinction',
        tag: 'RAG Cycle Rule',
        whyImportant: 'If resources have multiple instances, a cycle implies POTENTIAL deadlock, not guaranteed deadlock.'
      },
      {
        id: 6,
        point: 'Spinlocks (busy waiting) are only acceptable when expected lock holding times are shorter than the operating system context switch latency.',
        category: 'Vital Definition',
        tag: 'Spinlock Feasibility',
        whyImportant: 'Core systems concept tested in concurrency and OS architecture questions.'
      },
      {
        id: 7,
        point: 'Deadlock Recovery by preemption always risks process starvation unless the victim selection algorithm factors in rollback history and age.',
        category: 'High-Yield Fact',
        tag: 'Preemption Starvation',
        whyImportant: 'Often asked in short-answer questions regarding victim selection criteria.'
      }
    ],
    mcqs: [
      {
        id: 1,
        questionNumber: 1,
        type: 'concept-based',
        question: 'Which of the following conditions is violated if processes attempting to enter the critical section are perpetually blocked by other processes that are in their remainder sections?',
        options: {
          A: 'Mutual Exclusion',
          B: 'Progress',
          C: 'Bounded Waiting',
          D: 'Deadlock Freedom'
        },
        correctOption: 'B',
        explanation: 'Progress mandates that only processes currently competing for entry (not those in remainder sections) decide who enters next.'
      },
      {
        id: 2,
        questionNumber: 2,
        type: 'definition-based',
        question: 'What is a "Race Condition" in concurrent multi-threaded execution?',
        options: {
          A: 'A state where threads run at maximum clock frequency to compete for CPU time',
          B: 'A condition where the outcome of execution depends on the exact sequence or timing of concurrent thread access to shared data',
          C: 'A deadlock caused by two threads racing to acquire the same non-preemptible device',
          D: 'A situation where a high priority thread starves low priority threads indefinitely'
        },
        correctOption: 'B',
        explanation: 'A race condition occurs when concurrent threads manipulate shared state and the final result depends on non-deterministic thread scheduling.'
      },
      {
        id: 3,
        questionNumber: 3,
        type: 'application-based',
        question: 'Suppose a system uses a counting semaphore initialized to S = 7. If 12 wait() operations and 8 signal() operations are executed in arbitrary sequence, what is the final value of S?',
        options: {
          A: '15',
          B: '3',
          C: '0',
          D: '2'
        },
        correctOption: 'B',
        explanation: 'Final value = Initial + Signals - Waits = 7 + 8 - 12 = 3.'
      },
      {
        id: 4,
        questionNumber: 4,
        type: 'difference-based',
        question: 'What is the principal architectural difference between a Mutex and a Binary Semaphore?',
        options: {
          A: 'A mutex supports negative counter values while a semaphore does not',
          B: 'A mutex has an ownership semantic requiring only the acquiring thread to release it, whereas any thread can signal a semaphore',
          C: 'Binary semaphores can only be used across network sockets',
          D: 'A mutex does not guarantee mutual exclusion under high thread concurrency'
        },
        correctOption: 'B',
        explanation: 'Mutex locks possess ownership semantics (only the thread that locked can unlock), while semaphores are signaling primitives accessible by any thread.'
      },
      {
        id: 5,
        questionNumber: 5,
        type: 'factual',
        question: 'Which of the following is NOT one of the four Coffman conditions required for a deadlock to occur?',
        options: {
          A: 'Hold and Wait',
          B: 'No Preemption',
          C: 'Aging Priority Inversion',
          D: 'Circular Wait'
        },
        correctOption: 'C',
        explanation: 'The four Coffman conditions are: Mutual Exclusion, Hold and Wait, No Preemption, and Circular Wait.'
      },
      {
        id: 6,
        questionNumber: 6,
        type: 'tricky',
        question: 'In a Resource Allocation Graph (RAG), if a cycle is detected, what can definitively be concluded?',
        options: {
          A: 'A deadlock is guaranteed to exist in the system under all circumstances',
          B: 'A deadlock definitely exists only if all resource types in the graph possess single instances',
          C: 'The system has transitioned into an unrecoverable hardware fault',
          D: 'All processes involved in the cycle must be terminated simultaneously'
        },
        correctOption: 'B',
        explanation: 'A cycle in a RAG is both necessary and sufficient for deadlock ONLY if every resource type has exactly one instance. With multiple instances, a cycle is not sufficient.'
      },
      {
        id: 7,
        questionNumber: 7,
        type: 'concept-based',
        question: 'Peterson’s algorithm provides a software solution to the critical section problem for how many processes?',
        options: {
          A: 'Exactly 2 processes',
          B: 'N processes where N >= 2',
          C: 'Only multi-core architectures',
          D: 'Any number of processes through recursive token passing'
        },
        correctOption: 'A',
        explanation: 'Peterson’s classic algorithm is designed specifically for two cooperating processes (P0 and P1).'
      },
      {
        id: 8,
        questionNumber: 8,
        type: 'application-based',
        question: 'In Banker’s Algorithm, if Max[i] = [7, 5, 3] and Allocation[i] = [2, 3, 1], what is the Need[i] vector for process Pi?',
        options: {
          A: '[9, 8, 4]',
          B: '[5, 2, 2]',
          C: '[5, 8, 2]',
          D: '[2, 2, 2]'
        },
        correctOption: 'B',
        explanation: 'Need = Max - Allocation = [7-2, 5-3, 3-1] = [5, 2, 2].'
      },
      {
        id: 9,
        questionNumber: 9,
        type: 'difference-based',
        question: 'What is the relationship between an "Unsafe State" and a "Deadlock State" in OS resource management?',
        options: {
          A: 'Every unsafe state is a deadlock state',
          B: 'Every deadlock state is an unsafe state, but not all unsafe states are in deadlock',
          C: 'Unsafe states occur only during memory thrashing',
          D: 'There is no formal mathematical relationship between the two'
        },
        correctOption: 'B',
        explanation: 'Deadlock is a subset of unsafe states. An unsafe state only implies that the system cannot prevent processes from eventually requesting resources leading to deadlock.'
      },
      {
        id: 10,
        questionNumber: 10,
        type: 'definition-based',
        question: 'What is a "Spinlock"?',
        options: {
          A: 'A hardware bus controller that cycles disk head positions',
          B: 'A synchronization primitive where a thread repeatedly checks a lock condition in a tight loop without relinquishing the CPU',
          C: 'A scheduler queue that rotates processes using Round Robin',
          D: 'A deadlock resolution algorithm that rolls back database logs'
        },
        correctOption: 'B',
        explanation: 'A spinlock utilizes busy-waiting where the thread loops continuously evaluating the semaphore or lock flag until it becomes available.'
      },
      {
        id: 11,
        questionNumber: 11,
        type: 'concept-based',
        question: 'Which deadlock prevention technique specifically eliminates the "Circular Wait" condition?',
        options: {
          A: 'Preempting resources from waiting processes immediately',
          B: 'Requiring processes to request all resources at initialization time',
          C: 'Assigning a global linear order to all resource types and requiring monotonic requests',
          D: 'Running Banker’s safety check algorithm before every grant'
        },
        correctOption: 'C',
        explanation: 'Havender’s linear resource ordering guarantees that no circular wait chain can form because all requests must follow strictly ascending order.'
      },
      {
        id: 12,
        questionNumber: 12,
        type: 'tricky',
        question: 'Why does Peterson’s algorithm often fail on modern multi-core x86/ARM hardware without explicit memory barriers?',
        options: {
          A: 'Modern CPUs execute 64-bit rather than 32-bit instructions',
          B: 'Compilers and out-of-order processors may reorder independent read/write memory operations',
          C: 'Registers cannot store integer flags across threads',
          D: 'Multi-core systems do not permit shared memory pages'
        },
        correctOption: 'B',
        explanation: 'Modern compilers and processors reorder read and write instructions for optimization, which breaks the strict sequence assumed by Peterson’s logic.'
      },
      {
        id: 13,
        questionNumber: 13,
        type: 'application-based',
        question: 'A system has 4 processes and 12 identical tape drives. What is the maximum number of tape drives each process can claim (k) such that the system is guaranteed to be deadlock-free?',
        options: {
          A: '3',
          B: '4',
          C: '5',
          D: '2'
        },
        correctOption: 'A',
        explanation: 'Formula for deadlock freedom with n processes sharing m identical units: sum(Max_i) < m + n. Here 4k < 12 + 4 => 4k < 16 => k < 4 => k = 3.'
      },
      {
        id: 14,
        questionNumber: 14,
        type: 'factual',
        question: 'What is the name of the strategy where an operating system completely ignores the possibility of deadlocks?',
        options: {
          A: 'Banker’s Strategy',
          B: 'Ostrich Algorithm',
          C: 'Lamport’s Bakery Algorithm',
          D: 'Peterson’s Dismissal'
        },
        correctOption: 'B',
        explanation: 'The Ostrich Algorithm describes the practical choice to ignore rare deadlocks when prevention or detection costs exceed system restart overhead.'
      },
      {
        id: 15,
        questionNumber: 15,
        type: 'definition-based',
        question: 'In the context of concurrent process synchronization, what is "Bounded Waiting"?',
        options: {
          A: 'A hardware timer that triggers an interrupt every 10 milliseconds',
          B: 'A limit on the number of times other processes can enter critical sections after a process has requested entry',
          C: 'The maximum duration a thread can hold a spinlock before OS preemption',
          D: 'The maximum size of the ready queue in a multi-level scheduler'
        },
        correctOption: 'B',
        explanation: 'Bounded waiting guarantees no process suffers starvation by capping how many times other processes can enter their critical sections ahead of it.'
      },
      {
        id: 16,
        questionNumber: 16,
        type: 'concept-based',
        question: 'How does an operating system resolve the problem of busy-waiting in semaphore implementations?',
        options: {
          A: 'By swapping waiting processes to secondary storage swap space',
          B: 'By placing waiting processes onto a waiting queue associated with the semaphore and invoking block() and wakeup()',
          C: 'By dynamically upgrading spinlocks to recursive mutex locks',
          D: 'By doubling CPU clock frequency during critical section traversal'
        },
        correctOption: 'B',
        explanation: 'Non-busy-waiting semaphores place blocked processes into a waiting queue, suspending execution until a signal() operation invokes wakeup().'
      },
      {
        id: 17,
        questionNumber: 17,
        type: 'difference-based',
        question: 'How does Deadlock Prevention differ fundamentally from Deadlock Avoidance?',
        options: {
          A: 'Prevention runs at runtime; Avoidance is strictly static compile-time verification',
          B: 'Prevention negates one of the four Coffman conditions beforehand; Avoidance dynamically monitors resource state to ensure safety',
          C: 'Avoidance requires hardware watchdog timers while Prevention uses software traps',
          D: 'Prevention permits temporary cycles; Avoidance strictly forbids semaphores'
        },
        correctOption: 'B',
        explanation: 'Prevention imposes static structural rules to make at least one Coffman condition impossible. Avoidance makes dynamic grant decisions based on declared max resource requirements.'
      },
      {
        id: 18,
        questionNumber: 18,
        type: 'tricky',
        question: 'If a process executes wait(S) when the counting semaphore S has a value of 0, what occurs?',
        options: {
          A: 'S is incremented to 1 and the process continues immediately',
          B: 'A hardware divide-by-zero trap is triggered',
          C: 'The calling process is blocked and placed into the semaphore’s waiting queue',
          D: 'The process enters its critical section and resets S to 0'
        },
        correctOption: 'C',
        explanation: 'When S <= 0, wait() decrements S (or checks S == 0) and suspends the invoking process until another process executes signal(S).'
      },
      {
        id: 19,
        questionNumber: 19,
        type: 'factual',
        question: 'Which classic synchronization scenario highlights the danger of deadlock when five concurrent entities attempt to acquire two shared resources in identical orientation?',
        options: {
          A: 'Sleeping Barber Problem',
          B: 'Dining Philosophers Problem',
          C: 'Cigarette Smokers Problem',
          D: 'Readers-Writers Problem'
        },
        correctOption: 'B',
        explanation: 'The Dining Philosophers problem illustrates circular deadlock when all philosophers pick up their right chopsticks at the same time.'
      },
      {
        id: 20,
        questionNumber: 20,
        type: 'application-based',
        question: 'When recovering from a detected deadlock using process termination, which criterion is least relevant in selecting the victim process?',
        options: {
          A: 'How long the process has already executed and how much longer it needs to complete',
          B: 'How many and what types of resources the process currently holds',
          C: 'The color scheme of the terminal window from which the process was initiated',
          D: 'Whether the process is an interactive user process or a batch process'
        },
        correctOption: 'C',
        explanation: 'Victim selection factors process priority, CPU time used, resources held, remaining computation time, and process nature, not UI aesthetic properties.'
      }
    ],
    answerKey: [
      { questionNumber: 1, correctOption: 'B' },
      { questionNumber: 2, correctOption: 'B' },
      { questionNumber: 3, correctOption: 'B' },
      { questionNumber: 4, correctOption: 'B' },
      { questionNumber: 5, correctOption: 'C' },
      { questionNumber: 6, correctOption: 'B' },
      { questionNumber: 7, correctOption: 'A' },
      { questionNumber: 8, correctOption: 'B' },
      { questionNumber: 9, correctOption: 'B' },
      { questionNumber: 10, correctOption: 'B' },
      { questionNumber: 11, correctOption: 'C' },
      { questionNumber: 12, correctOption: 'B' },
      { questionNumber: 13, correctOption: 'A' },
      { questionNumber: 14, correctOption: 'B' },
      { questionNumber: 15, correctOption: 'B' },
      { questionNumber: 16, correctOption: 'B' },
      { questionNumber: 17, correctOption: 'B' },
      { questionNumber: 18, correctOption: 'C' },
      { questionNumber: 19, correctOption: 'B' },
      { questionNumber: 20, correctOption: 'C' }
    ],
    shortExplanations: [
      { questionNumber: 1, correctOption: 'B', explanation: 'Progress specifies that only non-remainder processes decide which process enters the critical section next.' },
      { questionNumber: 2, correctOption: 'B', explanation: 'A race condition arises when concurrent output depends on uncontrolled non-deterministic thread ordering.' },
      { questionNumber: 3, correctOption: 'B', explanation: 'Calculation: Initial 7 + 8 signals - 12 waits = 3.' },
      { questionNumber: 4, correctOption: 'B', explanation: 'Mutexes have thread ownership semantics; semaphores are pure signaling mechanisms without owner restrictions.' },
      { questionNumber: 5, correctOption: 'C', explanation: 'The 4 Coffman conditions are Mutual Exclusion, Hold & Wait, No Preemption, and Circular Wait.' },
      { questionNumber: 6, correctOption: 'B', explanation: 'A RAG cycle guarantees deadlock only with single-instance resource types; multiple instances require safety verification.' },
      { questionNumber: 7, correctOption: 'A', explanation: 'Peterson’s algorithm was formulated strictly for two cooperating processes using shared turn and flag arrays.' },
      { questionNumber: 8, correctOption: 'B', explanation: 'Need = Max - Allocation = [7-2, 5-3, 3-1] = [5, 2, 2].' },
      { questionNumber: 9, correctOption: 'B', explanation: 'All deadlock states are unsafe, but an unsafe state merely indicates vulnerability to future deadlocks.' },
      { questionNumber: 10, correctOption: 'B', explanation: 'Spinlocks consume CPU cycles actively polling a boolean variable until condition satisfaction.' },
      { questionNumber: 11, correctOption: 'C', explanation: 'Enforcing a global numeric resource order prevents circular resource acquisition chains.' },
      { questionNumber: 12, correctOption: 'B', explanation: 'Modern compiler optimization and CPU memory pipelines reorder memory stores/loads breaking Peterson’s sequential assumptions.' },
      { questionNumber: 13, correctOption: 'A', explanation: 'Deadlock-free formula: n * (k - 1) + 1 <= m => 4(k - 1) + 1 <= 12 => 4k - 3 <= 12 => 4k <= 15 => k = 3.' },
      { questionNumber: 14, correctOption: 'B', explanation: 'The Ostrich Algorithm is the policy of ignoring rare deadlocks when prevention costs outweigh recovery impact.' },
      { questionNumber: 15, correctOption: 'B', explanation: 'Bounded waiting places a ceiling on how many entries other threads can make before a waiting thread gets access.' },
      { questionNumber: 16, correctOption: 'B', explanation: 'Semaphores eliminate busy waiting by placing blocked threads onto a FIFO wait queue and invoking block().' },
      { questionNumber: 17, correctOption: 'B', explanation: 'Prevention statically eliminates one necessary Coffman condition; Avoidance evaluates dynamic state safety at runtime.' },
      { questionNumber: 18, correctOption: 'C', explanation: 'A wait() call on S = 0 blocks the executing process and places it into the semaphore’s waiting list.' },
      { questionNumber: 19, correctOption: 'B', explanation: 'Dining Philosophers is the standard benchmark problem modeling deadlock under symmetric competitive resource acquisition.' },
      { questionNumber: 20, correctOption: 'C', explanation: 'Terminal aesthetics do not influence algorithmic cost functions such as priority, runtime, or held resources.' }
    ],
    examPractice: {
      veryImportantQuestions: [
        {
          id: 1,
          type: 'VIQ',
          question: 'Define the Critical Section Problem and state the three mandatory requirements an acceptable solution must satisfy.',
          weightage: '5 Marks',
          keyPoints: [
            'Definition: Segment of code where shared resources are accessed.',
            'Requirement 1: Mutual Exclusion (only one process in CS).',
            'Requirement 2: Progress (selection made only by competing processes; no indefinite delay).',
            'Requirement 3: Bounded Waiting (limit on other processes entering before pending request is served).'
          ],
          modelAnswer: 'A critical section is a piece of code that accesses shared variables or resources. To prevent race conditions, any solution must satisfy: 1) Mutual Exclusion: If process Pi is executing in its critical section, no other processes can execute in their critical sections. 2) Progress: If no process is in its critical section and some wish to enter, only those not in their remainder sections can participate in deciding who enters next, ensuring no indefinite postponement. 3) Bounded Waiting: A bound must exist on the number of times other processes are allowed to enter their critical sections after a process has requested entry.'
        },
        {
          id: 2,
          type: 'VIQ',
          question: 'Enumerate the four Coffman conditions necessary for a system deadlock to occur.',
          weightage: '4-5 Marks',
          keyPoints: [
            'Mutual Exclusion: Non-shareable resource mode.',
            'Hold and Wait: Holding >= 1 resource while requesting more.',
            'No Preemption: Resources released only voluntarily.',
            'Circular Wait: Closed chain {P0, P1, ..., Pn} where Pi waits for Pi+1.'
          ],
          modelAnswer: 'For a deadlock to occur, all four Coffman conditions must hold simultaneously: 1. Mutual Exclusion: At least one resource must be held in a non-shareable mode. 2. Hold and Wait: A process must hold at least one resource while waiting to acquire additional resources held by others. 3. No Preemption: Resources cannot be forcibly seized; only the holding process can release them voluntarily. 4. Circular Wait: A set of processes {P0, P1, ..., Pn} exists such that P0 waits for P1, P1 waits for P2, and Pn waits for P0.'
        },
        {
          id: 3,
          type: 'VIQ',
          question: 'Explain the working of Banker’s Algorithm for deadlock avoidance with safety algorithm logic.',
          weightage: '8-10 Marks',
          keyPoints: [
            'Data structures: Available[m], Max[n][m], Allocation[n][m], Need[n][m] = Max - Allocation.',
            'Work = Available and Finish[i] = false for all i.',
            'Find index i where Finish[i] == false and Need_i <= Work.',
            'If found, Work = Work + Allocation_i; Finish[i] = true; repeat.',
            'If Finish[i] == true for all i, system is SAFE; otherwise UNSAFE.'
          ],
          modelAnswer: 'The Banker’s Algorithm is a deadlock avoidance algorithm for systems with multiple resource instances. It models resource allocation like a bank managing cash reserves. It tracks Available, Max, Allocation, and computes Need[i][j] = Max[i][j] - Allocation[i][j]. The Safety Algorithm initializes Work = Available and Finish[i] = false. It repeatedly finds a process Pi where Finish[i] == false and Need_i <= Work. When found, it assumes Pi will finish, releases Pi’s resources (Work = Work + Allocation_i), and marks Finish[i] = true. If all processes finish, the system is in a safe state with a verified safe sequence.'
        },
        {
          id: 4,
          type: 'VIQ',
          question: 'Differentiate between Deadlock Prevention, Deadlock Avoidance, and Deadlock Detection.',
          weightage: '6 Marks',
          keyPoints: [
            'Prevention: Statically invalidates one of four Coffman conditions; low runtime overhead but poor resource utilization.',
            'Avoidance: Dynamically evaluates resource requests against declared maximums (Banker\'s); avoids unsafe states.',
            'Detection: Periodically executes cycle-finding or safety check; recovers by process abort or resource preemption.'
          ],
          modelAnswer: '1) Deadlock Prevention: Imposes static constraints during design time to ensure at least one of the four Coffman conditions can never hold (e.g., ordering resources to prevent circular wait). It reduces resource utilization. 2) Deadlock Avoidance: System requires advance knowledge of maximum resource demands. At runtime, every request is dynamically examined to ensure the resulting state is Safe (e.g., Banker’s Algorithm). 3) Deadlock Detection: The system freely grants resources without restriction, then periodically executes detection algorithms (e.g., cycle detection in wait-for graphs) and initiates recovery if a deadlock is confirmed.'
        },
        {
          id: 5,
          type: 'VIQ',
          question: 'What is Peterson’s Solution? Write its pseudo-code and explain how it achieves Mutual Exclusion.',
          weightage: '6-8 Marks',
          keyPoints: [
            'Two-process software algorithm using boolean flag[2] and integer turn.',
            'flag[i] = true indicates desire to enter CS; turn = j gives courtesy to other process.',
            'Process waits while (flag[j] && turn == j).',
            'Mutual exclusion guaranteed because turn can take only one value (0 or 1).'
          ],
          modelAnswer: 'Peterson’s Solution is a classic two-process software synchronization algorithm. It uses two shared variables: boolean flag[2] (initialized to false) and int turn. When process Pi wants to enter the critical section, it executes:\n\nflag[i] = true;\nturn = j;\nwhile (flag[j] && turn == j) { /* busy wait */ }\n// Critical Section\nflag[i] = false;\n// Remainder Section\n\nMutual exclusion is guaranteed because if both attempt to enter simultaneously, turn can only hold either 0 or 1, forcing exactly one process to wait.'
        }
      ],
      shortAnswerQuestions: [
        {
          id: 1,
          type: 'short',
          question: 'What is the difference between a Counting Semaphore and a Binary Semaphore?',
          weightage: '2-3 Marks',
          modelAnswer: 'A binary semaphore takes values strictly between 0 and 1 (acting as a mutual exclusion lock), whereas a counting semaphore takes non-negative integer values over an unrestricted domain to manage multiple units of a finite resource.'
        },
        {
          id: 2,
          type: 'short',
          question: 'Why is busy waiting considered undesirable in single-processor systems?',
          weightage: '2 Marks',
          modelAnswer: 'In a single-processor system, busy-waiting spins the CPU in an idle loop evaluating a lock flag, consuming valuable processor clock cycles that could otherwise be utilized by the process currently holding the lock to finish its critical section.'
        },
        {
          id: 3,
          type: 'short',
          question: 'State the Havender rule for eliminating the Circular Wait condition.',
          weightage: '2-3 Marks',
          modelAnswer: 'Havender’s rule imposes a total linear ordering on all resource types F: R -> N. Processes may request resources only in strictly monotonically increasing numerical order (i.e., resource Rj can be requested only if F(Rj) > F(Ri) for all currently held Ri).'
        },
        {
          id: 4,
          type: 'short',
          question: 'Under what specific condition does a cycle in a Resource Allocation Graph NOT signify a deadlock?',
          weightage: '2-3 Marks',
          modelAnswer: 'A cycle in a Resource Allocation Graph does NOT guarantee a deadlock if resource nodes involved in the cycle have multiple instances, because other processes holding instances outside the cycle can complete and release their resources, breaking the dependency.'
        },
        {
          id: 5,
          type: 'short',
          question: 'Name two methods used to recover from an operating system deadlock after detection.',
          weightage: '2 Marks',
          modelAnswer: '1) Process Termination: Aborting all deadlocked processes or aborting one process at a time until the deadlock cycle is eliminated. 2) Resource Preemption: Successively preempting resources from victim processes and rolling them back to safe checkpoints.'
        }
      ],
      longAnswerQuestions: [
        {
          id: 1,
          type: 'long',
          question: 'Consider a system with 5 processes (P0 to P4) and 3 resource types (A, B, C with total instances 10, 5, 7). Given Allocation and Max matrices, determine if the system is in a safe state using Banker’s Safety Algorithm, find the safe sequence, and evaluate a new request.',
          weightage: '10-12 Marks',
          keyPoints: [
            'Step 1: Compute Available vector = Total - sum(Allocation).',
            'Step 2: Construct Need matrix where Need = Max - Allocation.',
            'Step 3: Run Safety algorithm iteration by iteration updating Work and Finish.',
            'Step 4: Formulate Safe Sequence (e.g. ⟨P1, P3, P4, P0, P2⟩).',
            'Step 5: Resource-Request algorithm comparison: Request <= Need and Request <= Available.'
          ],
          modelAnswer: 'To solve Banker\'s Algorithm examination questions:\n1. Compute Available = Total Resources - Sum of Allocations for each column.\n2. Compute Need matrix = Max[i][j] - Allocation[i][j] for each process.\n3. Safety Algorithm Execution:\n   - Set Work = Available, Finish = [false, false, false, false, false].\n   - Iterate through processes to find Pi with Finish[i] == false and Need_i <= Work.\n   - Once found, add Allocation_i to Work: Work = Work + Allocation_i, and set Finish[i] = true.\n   - Append Pi to the safe sequence list.\n4. Verification: If all processes Finish == true, the system is SAFE and the sequence ⟨P1, P3, P4, P0, P2⟩ is valid.\n5. Handling new request: If P1 makes request [1, 0, 2], verify Request <= Need_1 and Request <= Available. If true, pretend to allocate, re-run safety check, and grant only if safe state persists.'
        },
        {
          id: 2,
          type: 'long',
          question: 'Explain the Classic Readers-Writers Problem. Formulate the semaphore-based synchronization code for the First Readers-Writers problem (reader preference) and discuss the starvation implications.',
          weightage: '10 Marks',
          keyPoints: [
            'Problem statement: Multiple readers can read simultaneously; writers require exclusive access.',
            'Semaphores used: rw_mutex (initialized to 1) and mutex (initialized to 1), integer read_count = 0.',
            'Reader code: mutex wait/signal for read_count; first reader locks rw_mutex; last reader unlocks rw_mutex.',
            'Writer code: wait(rw_mutex); write(); signal(rw_mutex);',
            'Starvation analysis: Writers can starve indefinitely if new readers continuously arrive before read_count drops to 0.'
          ],
          modelAnswer: 'The Readers-Writers problem models access to a shared database. Readers only read and can access concurrently. Writers modify the database and require strictly exclusive access.\n\nStructure for Reader Preference:\nShared variables:\n- semaphore rw_mutex = 1; // protects critical database access\n- semaphore mutex = 1; // protects read_count\n- int read_count = 0;\n\nWriter Process:\nwait(rw_mutex);\n// Writing is performed\nsignal(rw_mutex);\n\nReader Process:\nwait(mutex);\nread_count++;\nif (read_count == 1) wait(rw_mutex); // First reader locks out writers\nsignal(mutex);\n\n// Reading is performed\n\nwait(mutex);\nread_count--;\nif (read_count == 0) signal(rw_mutex); // Last reader frees writers\nsignal(mutex);\n\nStarvation consequence: If a continuous succession of reader threads arrives, read_count never reaches zero, leading to writer starvation. Solution requires second readers-writers variant with writer priority or fair turnstile queues.'
        },
        {
          id: 3,
          type: 'long',
          question: 'Describe the Dining Philosophers Problem. Illustrate why a naive semaphore implementation deadlocks, and provide two robust dead-lock free solutions.',
          weightage: '10 Marks',
          keyPoints: [
            'Setup: 5 philosophers alternate between thinking and eating; 5 chopsticks (chopstick[5] semaphores = 1).',
            'Deadlock scenario: If all 5 pick up left chopstick simultaneously, all right chopsticks are occupied (Circular Wait).',
            'Solution 1: Asymmetric philosopher (odd philosopher picks left then right; even picks right then left).',
            'Solution 2: Allow at most 4 philosophers to sit at the table simultaneously using counting semaphore table = 4.',
            'Solution 3: Monitor / state-based approach (pickup both chopsticks atomically only if both neighbors are not eating).'
          ],
          modelAnswer: 'The Dining Philosophers problem features 5 philosophers sitting around a circular table with 5 chopsticks. Each philosopher needs two adjacent chopsticks to eat.\n\nNaive Deadlock:\nEach philosopher Pi executes:\nwait(chopstick[i]); // pick left\nwait(chopstick[(i + 1) % 5]); // pick right\neat();\nsignal(chopstick[i]);\nsignal(chopstick[(i + 1) % 5]);\n\nIf all 5 philosophers simultaneously execute wait(chopstick[i]), every chopstick is held and every philosopher blocks waiting for the right chopstick, creating a classic circular wait deadlock.\n\nTwo Robust Solutions:\n1. Asymmetric Philosophers: Number philosophers 0 to 4. Even philosophers pick up the left chopstick first, then the right. Odd philosophers pick up the right chopstick first, then the left. This breaks the symmetric circular wait condition.\n2. Limiting Concurrency via Semaphore: Use a counting semaphore room initialized to 4. At most 4 philosophers are allowed to sit at the table simultaneously. By the Pigeonhole Principle, at least one philosopher is guaranteed to obtain both chopsticks and eat, preventing deadlock.'
        }
      ]
    }
  },
  {
    id: 'cn-transport-tcp',
    title: 'Computer Networks: Transport Layer, TCP & Congestion Control',
    sourceNoteSummary: 'University networking notes on UDP vs TCP, 3-Way Handshake, TCP 4-Way Teardown, Flow Control (Sliding Window), Congestion Control (Slow Start, Congestion Avoidance, Fast Retransmit, Fast Recovery), and Stop-and-Wait / GBN / Selective Repeat.',
    generatedAt: new Date().toISOString(),
    quickSummary: {
      topicTitle: 'Transport Layer: TCP, Flow & Congestion Control',
      estimatedReadTime: '4 mins 30 secs',
      overview: 'The transport layer provides logical, end-to-end process-to-process communication. While UDP offers connectionless best-effort delivery, TCP provides connection-oriented, reliable, in-order byte-stream delivery with flow and congestion control.',
      sections: [
        {
          heading: '1. UDP vs TCP Fundamentals',
          keyTakeaway: 'UDP is lightweight, header-minimal (8 bytes) and unacknowledged; TCP is reliable, full-duplex, stream-oriented (20-60 bytes header).',
          bulletPoints: [
            'UDP Header: 8 bytes (Source Port, Dest Port, Length, Checksum). No handshakes, no congestion throttle, zero connection state overhead.',
            'TCP Header: 20 bytes min (up to 60 with Options). Key flags: SYN, ACK, FIN, RST, PSH, URG.',
            'TCP 3-Way Handshake: 1) Client sends SYN (seq=x), 2) Server responds SYN-ACK (seq=y, ack=x+1), 3) Client sends ACK (seq=x+1, ack=y+1).',
            'TCP Connection Teardown: 4-Way handshake with FIN and ACK in both directions. TIME_WAIT state lasts 2*MSL to ensure late ACKs clear.'
          ],
          highlights: [
            {
              label: 'TIME_WAIT State',
              type: 'fact',
              text: 'Active closer enters TIME_WAIT for 2 MSL (Maximum Segment Lifetime) to permit retransmission of final ACK and prevent old segments confusing new connections.'
            }
          ]
        },
        {
          heading: '2. Sliding Window & ARQ Protocols',
          keyTakeaway: 'Go-Back-N resends all unacknowledged packets upon timeout; Selective Repeat buffers out-of-order packets and resends only corrupted/lost frames.',
          bulletPoints: [
            'Stop-and-Wait: Sender transmits 1 packet and waits for ACK before sending next. Very low link utilization on high Bandwidth-Delay Product (BDP) links.',
            'Go-Back-N (GBN): Sender window size N; receiver window size 1 (cumulative ACKs). On timeout for packet k, retransmits all packets k through k+N-1.',
            'Selective Repeat (SR): Sender window N; receiver window N. Receiver buffers out-of-order frames within window and sends individual ACKs.',
            'Window Size Rule: In GBN, max sender window = 2^k - 1. In SR, max sender & receiver window = 2^(k-1) to avoid sequence number ambiguity.'
          ],
          highlights: [
            {
              label: 'Window Math Constraint',
              type: 'formula',
              text: 'For k-bit sequence numbers: GBN W_sender <= 2^k - 1; Selective Repeat W_sender = W_receiver <= 2^(k-1).'
            }
          ]
        },
        {
          heading: '3. TCP Congestion Control Mechanics',
          keyTakeaway: 'Maintains cwnd (congestion window) and ssthresh (slow start threshold) to prevent intermediate router buffer collapse.',
          bulletPoints: [
            'Slow Start: cwnd starts at 1 MSS (or initial window) and doubles every RTT (exponential growth: cwnd = cwnd + 1 per ACK) until cwnd >= ssthresh.',
            'Congestion Avoidance: Once cwnd >= ssthresh, grows linearly by 1 MSS per RTT (AIMD - Additive Increase Multiplicative Decrease).',
            'Timeout Event (Reno/Tahoe): Indicates severe loss. ssthresh = cwnd / 2; cwnd drops back to 1 MSS (resets to Slow Start).',
            'Triple Duplicate ACKs (Fast Retransmit & Fast Recovery): Retransmits lost segment immediately without waiting for retransmission timer. In TCP Reno, ssthresh = cwnd/2, cwnd = ssthresh + 3 MSS.'
          ]
        }
      ],
      speedRevisionPoints: [
        'TCP 3-way handshake: SYN -> SYN-ACK -> ACK.',
        'Flow Control uses Receiver Advertised Window (rwnd); Congestion Control uses cwnd. Effective window = min(rwnd, cwnd).',
        'GBN sender window <= 2^k - 1; SR sender window <= 2^(k-1).',
        'TCP Reno on 3 Duplicate ACKs: Fast Retransmit + Fast Recovery (halves cwnd instead of dropping to 1).',
        'TIME_WAIT duration is 2 * MSL (Maximum Segment Lifetime).'
      ]
    },
    mustRemember: [
      {
        id: 1,
        point: 'Effective Send Window is the MINIMUM of Congestion Window (cwnd) and Receiver Advertised Window (rwnd): SendWindow = min(cwnd, rwnd).',
        category: 'Core Formula/Rule',
        tag: 'Flow vs Congestion',
        whyImportant: 'Guaranteed to appear on nearly every university networking exam.'
      },
      {
        id: 2,
        point: 'Selective Repeat requires that Sender Window + Receiver Window <= 2^k. With equal windows, W_max = 2^(k-1).',
        category: 'Core Formula/Rule',
        tag: 'SR Window Limit',
        whyImportant: 'Standard numerical trap question for sequence space collisions.'
      },
      {
        id: 3,
        point: 'In TCP Reno: Timeout drops cwnd to 1 MSS; 3 Duplicate ACKs halves cwnd (Fast Recovery) without dropping to 1 MSS.',
        category: 'Crucial Distinction',
        tag: 'Reno vs Tahoe',
        whyImportant: 'Core distinction between TCP Tahoe (always drops to 1) and TCP Reno (halves cwnd on 3 dup ACKs).'
      },
      {
        id: 4,
        point: 'UDP header size is exactly 8 bytes (64 bits), while the base TCP header size without options is 20 bytes (160 bits).',
        category: 'High-Yield Fact',
        tag: 'Header Sizes',
        whyImportant: 'Frequent 1-mark or multiple-choice question in exams.'
      },
      {
        id: 5,
        point: 'The TIME_WAIT state is entered solely by the endpoint that initiated active close, and it lasts for 2 * MSL.',
        category: 'Frequent Exam Trap',
        tag: 'TIME_WAIT Role',
        whyImportant: 'Crucial distinction between active closer and passive closer in connection termination.'
      }
    ],
    mcqs: [
      {
        id: 1,
        questionNumber: 1,
        type: 'concept-based',
        question: 'Which entity determines the value of rwnd (Receive Window) in TCP transmission?',
        options: {
          A: 'The intermediate network routers',
          B: 'The receiving host based on its current available buffer space',
          C: 'The sending host based on Round Trip Time (RTT)',
          D: 'The Domain Name System resolver'
        },
        correctOption: 'B',
        explanation: 'The receiver explicitly advertises rwnd in TCP header ACK packets to communicate available buffer capacity to the sender.'
      },
      {
        id: 2,
        questionNumber: 2,
        type: 'definition-based',
        question: 'What is the standard fixed header size of a User Datagram Protocol (UDP) packet?',
        options: {
          A: '20 bytes',
          B: '8 bytes',
          C: '16 bytes',
          D: '4 bytes'
        },
        correctOption: 'B',
        explanation: 'UDP header consists of 4 fields of 2 bytes each (Source Port, Dest Port, Length, Checksum), totaling 8 bytes.'
      },
      {
        id: 3,
        questionNumber: 3,
        type: 'application-based',
        question: 'If 4-bit sequence numbers are used in a Selective Repeat ARQ protocol, what is the maximum permissible window size for both sender and receiver?',
        options: {
          A: '16',
          B: '15',
          C: '8',
          D: '7'
        },
        correctOption: 'C',
        explanation: 'In Selective Repeat, W_max <= 2^(k-1). For k = 4 bits, 2^(4-1) = 2^3 = 8.'
      },
      {
        id: 4,
        questionNumber: 4,
        type: 'difference-based',
        question: 'How does TCP Reno react to 3 duplicate ACKs compared to a Retransmission Timeout (RTO)?',
        options: {
          A: 'Both reset cwnd to 1 MSS',
          B: '3 Duplicate ACKs triggers Fast Recovery halving cwnd, while Timeout resets cwnd to 1 MSS',
          C: 'Timeout increases cwnd exponentially while 3 Dup ACKs halts transmission',
          D: '3 Duplicate ACKs closes the socket immediately'
        },
        correctOption: 'B',
        explanation: '3 Duplicate ACKs indicates mild congestion where segments are still reaching the receiver, so Reno cuts cwnd in half. Timeout indicates severe congestion, resetting cwnd to 1.'
      },
      {
        id: 5,
        questionNumber: 5,
        type: 'factual',
        question: 'Which TCP flag is set in the very first segment transmitted during connection establishment?',
        options: {
          A: 'ACK',
          B: 'SYN',
          C: 'FIN',
          D: 'PSH'
        },
        correctOption: 'B',
        explanation: 'The client sends an initial segment with only the SYN flag set to initiate the 3-way handshake.'
      },
      {
        id: 6,
        questionNumber: 6,
        type: 'tricky',
        question: 'Why does the endpoint initiating active close wait in the TIME_WAIT state for 2 * MSL?',
        options: {
          A: 'To wait for the user to type the next terminal command',
          B: 'To allow any late duplicate packets from the connection to expire in the network and ensure final ACK reaches the peer',
          C: 'To recalculate the Round Trip Time for subsequent connections',
          D: 'To flush the DNS cache on the host operating system'
        },
        correctOption: 'B',
        explanation: '2 MSL guarantees that any lingering duplicate segments dissipate from the network, preventing cross-talk with subsequent connections on the same port tuple.'
      },
      {
        id: 7,
        questionNumber: 7,
        type: 'concept-based',
        question: 'In TCP Slow Start phase, how does the congestion window (cwnd) increase upon receipt of each ACK segment?',
        options: {
          A: 'Increases linearly by 1 MSS per RTT',
          B: 'Increases by 1 MSS for every valid ACK received, effectively doubling cwnd each RTT',
          C: 'Triples each RTT',
          D: 'Remains strictly constant until ssthresh is reached'
        },
        correctOption: 'B',
        explanation: 'Adding 1 MSS per ACK results in exponential doubling of cwnd every round-trip time (RTT).'
      },
      {
        id: 8,
        questionNumber: 8,
        type: 'application-based',
        question: 'A TCP sender has cwnd = 24 KB and the receiver advertises rwnd = 16 KB. What is the maximum volume of unacknowledged data the sender is permitted to transmit?',
        options: {
          A: '40 KB',
          B: '24 KB',
          C: '16 KB',
          D: '8 KB'
        },
        correctOption: 'C',
        explanation: 'Send Window = min(cwnd, rwnd) = min(24 KB, 16 KB) = 16 KB.'
      },
      {
        id: 9,
        questionNumber: 9,
        type: 'difference-based',
        question: 'What is the receiver window size in the Go-Back-N protocol?',
        options: {
          A: 'Equal to sender window N',
          B: 'Exactly 1',
          C: '2^k - 1',
          D: 'Infinite'
        },
        correctOption: 'B',
        explanation: 'Go-Back-N receiver accepts packets only in strict sequential order, so its receiver window size is always 1.'
      },
      {
        id: 10,
        questionNumber: 10,
        type: 'definition-based',
        question: 'What is "Silly Window Syndrome" in TCP?',
        options: {
          A: 'A bug where the window size exceeds 65,535 bytes without window scaling',
          B: 'A performance degradation where data is transmitted in tiny segments due to slow sender production or slow receiver consumption',
          C: 'A condition where a hacker injects falsified RST packets',
          D: 'An infinite loop caused by recursive DNS lookups'
        },
        correctOption: 'B',
        explanation: 'Silly Window Syndrome occurs when TCP exchanges tiny segments with large header overhead because either sender produces data slowly or receiver frees buffer 1 byte at a time.'
      },
      {
        id: 11,
        questionNumber: 11,
        type: 'concept-based',
        question: 'Nagle’s algorithm is implemented on which side to prevent small packet generation?',
        options: {
          A: 'Receiver side',
          B: 'Sender side',
          C: 'Default Gateway router',
          D: 'Core BGP switches'
        },
        correctOption: 'B',
        explanation: 'Nagle’s algorithm runs on the sender to aggregate small outgoing messages until a full MSS can be sent or previous data is acknowledged.'
      },
      {
        id: 12,
        questionNumber: 12,
        type: 'tricky',
        question: 'If a TCP connection receives segment sequence number 5000 with payload 1000 bytes, what ACK number does the receiver send in response?',
        options: {
          A: '5000',
          B: '6000',
          C: '6001',
          D: '1000'
        },
        correctOption: 'B',
        explanation: 'TCP ACKs specify the NEXT expected byte. Since bytes 5000 to 5999 were received, next expected byte is 5000 + 1000 = 6000.'
      },
      {
        id: 13,
        questionNumber: 13,
        type: 'application-based',
        question: 'In a Go-Back-N protocol with 3-bit sequence numbers, what is the maximum sender window size?',
        options: {
          A: '8',
          B: '7',
          C: '4',
          D: '3'
        },
        correctOption: 'B',
        explanation: 'For GBN, W_sender <= 2^k - 1. For k = 3 bits, W_sender <= 2^3 - 1 = 7.'
      },
      {
        id: 14,
        questionNumber: 14,
        type: 'factual',
        question: 'Which of the following transport protocols is strictly connectionless and does not perform flow control?',
        options: {
          A: 'TCP',
          B: 'SCTP',
          C: 'UDP',
          D: 'DCCP'
        },
        correctOption: 'C',
        explanation: 'UDP provides connectionless, unacknowledged datagram transmission without flow or congestion control.'
      },
      {
        id: 15,
        questionNumber: 15,
        type: 'definition-based',
        question: 'What is "Bandwidth-Delay Product" (BDP)?',
        options: {
          A: 'The total time a packet waits inside a router queue',
          B: 'The maximum volume of data that can be in-transit (in the pipe) between sender and receiver at any moment',
          C: 'The frequency bandwidth divided by signal propagation speed',
          D: 'The ratio of TCP header overhead to payload'
        },
        correctOption: 'B',
        explanation: 'BDP = Link Bandwidth (bps) * RTT (seconds). It represents the maximum data volume filling the network pipe.'
      },
      {
        id: 16,
        questionNumber: 16,
        type: 'concept-based',
        question: 'What triggers "Fast Retransmit" in TCP Tahoe and Reno?',
        options: {
          A: 'Receipt of 3 duplicate ACKs (4 identical ACKs in total)',
          B: 'The expiration of the 500ms retransmission timer',
          C: 'A ICMP Source Quench message from an intermediate switch',
          D: 'A zero-window advertisement from receiver'
        },
        correctOption: 'A',
        explanation: 'Receiving 3 duplicate ACKs beyond the original ACK informs sender that a specific segment was lost and subsequent segments were received.'
      },
      {
        id: 17,
        questionNumber: 17,
        type: 'difference-based',
        question: 'What happens to out-of-order packets in Go-Back-N compared to Selective Repeat?',
        options: {
          A: 'GBN buffers them; SR drops them',
          B: 'GBN discards them; SR buffers them in the receiver window',
          C: 'Both protocols drop them immediately',
          D: 'Both protocols forward them directly to the application layer'
        },
        correctOption: 'B',
        explanation: 'GBN discards any out-of-order packet because its receive window is 1. Selective Repeat buffers out-of-order packets within its receive window.'
      },
      {
        id: 18,
        questionNumber: 18,
        type: 'tricky',
        question: 'In TCP Congestion Avoidance, if cwnd = 16 MSS, how much does cwnd increase after one successful RTT where all 16 MSS are acknowledged?',
        options: {
          A: 'Doubles to 32 MSS',
          B: 'Increases by 1 MSS to 17 MSS',
          C: 'Increases to 24 MSS',
          D: 'Remains unchanged at 16 MSS'
        },
        correctOption: 'B',
        explanation: 'Congestion avoidance operates on Additive Increase, growing by 1 MSS per RTT (or 1/cwnd per ACK).'
      },
      {
        id: 19,
        questionNumber: 19,
        type: 'factual',
        question: 'Which field in the TCP header is used to support window sizes greater than 65,535 bytes?',
        options: {
          A: 'Urgent Pointer',
          B: 'Checksum',
          C: 'Window Scale Option (in TCP Options)',
          D: 'Sequence Number Extension'
        },
        correctOption: 'C',
        explanation: 'The TCP Window Scale option (RFC 1323) shifts the 16-bit window field left by up to 14 bits, enabling window sizes up to 1 GB.'
      },
      {
        id: 20,
        questionNumber: 20,
        type: 'application-based',
        question: 'If a sender transmits a segment with SYN=1 and ACK=0, what is the receiver expected to reply with during standard connection establishment?',
        options: {
          A: 'SYN=0, ACK=0',
          B: 'SYN=1, ACK=1',
          C: 'FIN=1, ACK=1',
          D: 'RST=1, ACK=0'
        },
        correctOption: 'B',
        explanation: 'In the second step of the 3-way handshake, the receiver replies with SYN=1 and ACK=1.'
      }
    ],
    answerKey: [
      { questionNumber: 1, correctOption: 'B' },
      { questionNumber: 2, correctOption: 'B' },
      { questionNumber: 3, correctOption: 'C' },
      { questionNumber: 4, correctOption: 'B' },
      { questionNumber: 5, correctOption: 'B' },
      { questionNumber: 6, correctOption: 'B' },
      { questionNumber: 7, correctOption: 'B' },
      { questionNumber: 8, correctOption: 'C' },
      { questionNumber: 9, correctOption: 'B' },
      { questionNumber: 10, correctOption: 'B' },
      { questionNumber: 11, correctOption: 'B' },
      { questionNumber: 12, correctOption: 'B' },
      { questionNumber: 13, correctOption: 'B' },
      { questionNumber: 14, correctOption: 'C' },
      { questionNumber: 15, correctOption: 'B' },
      { questionNumber: 16, correctOption: 'A' },
      { questionNumber: 17, correctOption: 'B' },
      { questionNumber: 18, correctOption: 'B' },
      { questionNumber: 19, correctOption: 'C' },
      { questionNumber: 20, correctOption: 'B' }
    ],
    shortExplanations: [
      { questionNumber: 1, correctOption: 'B', explanation: 'rwnd reflects receiver buffer free space to enforce flow control.' },
      { questionNumber: 2, correctOption: 'B', explanation: 'UDP header is fixed at 8 bytes (ports, length, checksum).' },
      { questionNumber: 3, correctOption: 'C', explanation: 'Selective Repeat requires W <= 2^(k-1) = 2^3 = 8.' },
      { questionNumber: 4, correctOption: 'B', explanation: 'Reno halves cwnd on 3 dup ACKs (Fast Recovery) but drops to 1 on timeout.' },
      { questionNumber: 5, correctOption: 'B', explanation: 'Connection setup initiates with a SYN segment.' },
      { questionNumber: 6, correctOption: 'B', explanation: 'TIME_WAIT holds for 2 MSL to prevent cross-connection segment ghosting.' },
      { questionNumber: 7, correctOption: 'B', explanation: 'Slow start doubles cwnd every RTT by incrementing 1 MSS per ACK.' },
      { questionNumber: 8, correctOption: 'C', explanation: 'Send window is min(cwnd, rwnd) = min(24, 16) = 16 KB.' },
      { questionNumber: 9, correctOption: 'B', explanation: 'GBN receiver window is 1 because out-of-order frames are dropped.' },
      { questionNumber: 10, correctOption: 'B', explanation: 'Silly Window Syndrome produces heavy header overhead from tiny payloads.' },
      { questionNumber: 11, correctOption: 'B', explanation: 'Nagle’s algorithm operates on the sender to aggregate tiny packets.' },
      { questionNumber: 12, correctOption: 'B', explanation: 'ACK indicates next byte expected: 5000 + 1000 = 6000.' },
      { questionNumber: 13, correctOption: 'B', explanation: 'GBN maximum sender window = 2^k - 1 = 2^3 - 1 = 7.' },
      { questionNumber: 14, correctOption: 'C', explanation: 'UDP is connectionless and does not manage flow or congestion.' },
      { questionNumber: 15, correctOption: 'B', explanation: 'BDP measures total bytes capacity in flight across the network pipe.' },
      { questionNumber: 16, correctOption: 'A', explanation: 'Fast Retransmit is initiated upon detecting 3 duplicate ACKs.' },
      { questionNumber: 17, correctOption: 'B', explanation: 'Selective Repeat buffers out-of-order packets while GBN discards them.' },
      { questionNumber: 18, correctOption: 'B', explanation: 'Congestion avoidance applies Additive Increase (+1 MSS per RTT).' },
      { questionNumber: 19, correctOption: 'C', explanation: 'Window Scale Option left-shifts the 16-bit window up to 1 GB.' },
      { questionNumber: 20, correctOption: 'B', explanation: 'The second packet in a 3-way handshake carries SYN=1 and ACK=1.' }
    ],
    examPractice: {
      veryImportantQuestions: [
        {
          id: 1,
          type: 'VIQ',
          question: 'Describe the TCP 3-Way Handshake mechanism with a sequence diagram and explain why a 2-way handshake is insufficient.',
          weightage: '6-8 Marks',
          keyPoints: [
            'Step 1: Client -> Server: SYN, seq=x.',
            'Step 2: Server -> Client: SYN-ACK, seq=y, ack=x+1.',
            'Step 3: Client -> Server: ACK, seq=x+1, ack=y+1.',
            'Why 2-way fails: Old delayed SYN segments could create phantom half-open connections and allocate wasted server resources.'
          ],
          modelAnswer: 'The TCP 3-Way Handshake establishes connection synchronization:\n1. Client -> Server: SYN=1, Seq=x (Client proposes initial sequence number x).\n2. Server -> Client: SYN=1, ACK=1, Seq=y, Ack=x+1 (Server acknowledges x and proposes y).\n3. Client -> Server: ACK=1, Seq=x+1, Ack=y+1 (Client acknowledges y).\n\nA 2-way handshake is insufficient because an old, delayed duplicate SYN packet could arrive at the server after the original connection ended. With a 2-way handshake, the server would immediately open a connection and allocate resources without verifying whether the client actually initiated the request. The 3rd ACK verifies the client is live and acknowledges the server’s sequence number.'
        },
        {
          id: 2,
          type: 'VIQ',
          question: 'Differentiate between Go-Back-N and Selective Repeat ARQ protocols with respect to sender window, receiver window, ACK type, and buffer requirements.',
          weightage: '6 Marks',
          keyPoints: [
            'Sender Window: GBN <= 2^k - 1; SR <= 2^(k-1).',
            'Receiver Window: GBN = 1; SR = Sender Window.',
            'ACK Type: GBN uses cumulative ACKs; SR uses selective/individual ACKs.',
            'Buffer: GBN needs no receiver buffer; SR requires receiver buffer for out-of-order packets.'
          ],
          modelAnswer: '1. Window Sizes: In GBN with k-bit sequence numbers, W_sender <= 2^k - 1, and W_receiver = 1. In SR, W_sender = W_receiver <= 2^(k-1).\n2. Out-of-order Handling: GBN discards any out-of-order frame. SR accepts and buffers out-of-order frames within receiver window.\n3. ACKs: GBN uses cumulative ACKs (acknowledging all frames up to N). SR uses individual/selective ACKs for each correctly received frame.\n4. Retransmission: GBN retransmits the lost frame and all subsequent sent frames (wasting bandwidth). SR retransmits only the specific lost frame.\n5. Receiver Buffer: GBN requires zero receiver buffering; SR requires buffer storage equal to receiver window size.'
        },
        {
          id: 3,
          type: 'VIQ',
          question: 'Explain the four phases of TCP Congestion Control: Slow Start, Congestion Avoidance, Fast Retransmit, and Fast Recovery.',
          weightage: '8-10 Marks',
          keyPoints: [
            'Slow Start: cwnd starts at 1 MSS, doubles every RTT until ssthresh.',
            'Congestion Avoidance: cwnd grows linearly (+1 MSS/RTT) when cwnd >= ssthresh.',
            'Fast Retransmit: 3 duplicate ACKs trigger instant retransmission of lost segment before timeout.',
            'Fast Recovery (TCP Reno): ssthresh = cwnd / 2; cwnd set to ssthresh + 3 MSS, continuing linear increase.'
          ],
          modelAnswer: 'TCP Congestion Control regulates transmission based on network capacity:\n1. Slow Start: cwnd starts at 1 MSS. For each ACK received, cwnd increases by 1 MSS, effectively doubling cwnd each RTT (exponential growth). Continues until cwnd reaches ssthresh.\n2. Congestion Avoidance: When cwnd >= ssthresh, growth shifts to linear: cwnd increases by 1 MSS per RTT (AIMD additive increase).\n3. Fast Retransmit: Upon receiving 3 duplicate ACKs, the sender infers packet loss and retransmits the missing segment immediately without waiting for the retransmission timer.\n4. Fast Recovery: Instead of resetting cwnd to 1 (like TCP Tahoe), TCP Reno sets ssthresh = cwnd/2 and sets cwnd = ssthresh + 3 MSS, avoiding a return to Slow Start and preserving throughput.'
        },
        {
          id: 4,
          type: 'VIQ',
          question: 'What is Flow Control in TCP? How does the Sliding Window protocol prevent receiver buffer overflow?',
          weightage: '5 Marks',
          keyPoints: [
            'Purpose: Speed matching between fast sender and slow receiver.',
            'Mechanism: Receiver advertises rwnd (Receive Window) in TCP header.',
            'Calculation: Max allowed in flight = min(cwnd, rwnd).',
            'Zero Window: When rwnd = 0, sender stops sending but sends periodic probe packets.'
          ],
          modelAnswer: 'Flow Control prevents a fast sender from overwhelming a slow receiver’s buffer. In TCP, the receiver dynamically tracks its spare buffer capacity: rwnd = RcvBuffer - [LastByteRcvd - LastByteRead]. The receiver advertises this rwnd in every ACK header. The sender ensures that [LastByteSent - LastByteAcked] <= rwnd. If buffer becomes full, receiver advertises rwnd = 0 (Zero Window). The sender then pauses transmission and issues periodic 1-byte probe segments to solicit window updates until the receiver application frees buffer space.'
        },
        {
          id: 5,
          type: 'VIQ',
          question: 'Why does Selective Repeat require sender and receiver window sizes to be at most 2^(k-1) for a k-bit sequence number?',
          weightage: '5-6 Marks',
          keyPoints: [
            'Problem: Sequence number overlap / ambiguity.',
            'Example: If k = 2 (sequence numbers 0, 1, 2, 3) and window = 3.',
            'Scenario where all ACKs are lost: Sender resends original frames 0, 1, 2.',
            'Receiver ambiguity: Receiver cannot distinguish whether new frame 0 or retransmitted old frame 0 was received.'
          ],
          modelAnswer: 'If window size exceeds 2^(k-1), the sequence space wraps around, causing overlap between the current receive window and the previous send window. For example, if k = 2 bits (sequences 0, 1, 2, 3) and window size is 3:\n- Sender transmits packets 0, 1, 2.\n- Receiver gets all 3, sends ACKs, and advances window to [3, 0, 1].\n- If all ACKs are lost, sender times out and retransmits packet 0.\n- Receiver is expecting new packet 0 and cannot tell whether this is the new packet 0 or a retransmitted old packet 0.\nRestricting W_sender = W_receiver <= 2^(k-1) guarantees that the previous window and new window never overlap in sequence space.'
        }
      ],
      shortAnswerQuestions: [
        {
          id: 1,
          type: 'short',
          question: 'Why is UDP preferred over TCP for real-time multiplayer gaming and live audio streaming?',
          weightage: '2-3 Marks',
          modelAnswer: 'UDP eliminates connection handshake delays, retransmission overhead (which would render stale audio/video frames useless), and head-of-line blocking, prioritizing immediate low-latency delivery over guaranteed packet recovery.'
        },
        {
          id: 2,
          type: 'short',
          question: 'What is the purpose of the Checksum field in the UDP header, and is it mandatory in IPv4 vs IPv6?',
          weightage: '2 Marks',
          modelAnswer: 'The checksum detects bit errors in the UDP header, payload, and pseudo-IP header. In IPv4 it is optional (can be set to 0), but in IPv6 it is strictly mandatory because IPv6 headers omit a header checksum.'
        },
        {
          id: 3,
          type: 'short',
          question: 'Define Maximum Segment Size (MSS) and its typical value on an Ethernet network.',
          weightage: '2-3 Marks',
          modelAnswer: 'MSS is the largest chunk of application data TCP will send in a single IP packet, excluding TCP/IP headers. On standard Ethernet (MTU = 1500 bytes), MSS = MTU (1500) - IP Header (20) - TCP Header (20) = 1460 bytes.'
        },
        {
          id: 4,
          type: 'short',
          question: 'How does Nagle’s algorithm solve the small packet problem?',
          weightage: '2-3 Marks',
          modelAnswer: 'Nagle’s algorithm specifies that a sender with unacknowledged data in flight must buffer any subsequent small user data until an entire MSS segment is accumulated or an ACK for outstanding data arrives.'
        },
        {
          id: 5,
          type: 'short',
          question: 'What is the difference between TCP Tahoe and TCP Reno when a packet loss is signaled by 3 duplicate ACKs?',
          weightage: '2 Marks',
          modelAnswer: 'TCP Tahoe sets ssthresh = cwnd/2 and resets cwnd to 1 MSS entering Slow Start, while TCP Reno sets ssthresh = cwnd/2 and sets cwnd = ssthresh + 3 MSS entering Fast Recovery without resetting to 1.'
        }
      ],
      longAnswerQuestions: [
        {
          id: 1,
          type: 'long',
          question: 'Given an initial TCP connection with ssthresh = 32 KB and cwnd = 1 MSS (1 KB). A timeout occurs at transmission round 14 when cwnd reaches 40 KB. Graph and calculate cwnd progression from round 1 to round 20 under TCP Reno and TCP Tahoe.',
          weightage: '10 Marks',
          keyPoints: [
            'Round 1 to 6: Slow Start exponential growth (1, 2, 4, 8, 16, 32).',
            'Round 6 to 14: Congestion Avoidance linear growth (+1/round: 33, 34, ..., 40 KB).',
            'Round 14 event: Timeout at 40 KB => New ssthresh = 40 / 2 = 20 KB.',
            'Tahoe & Reno reaction to Timeout: Both reset cwnd to 1 KB (Slow Start).',
            'Round 15 to 19: Slow Start from 1 to 20 KB; Round 20: 21 KB (linear).'
          ],
          modelAnswer: '1. Phase 1 (Slow Start): cwnd begins at 1 KB and doubles every round: Round 1: 1 KB, R2: 2, R3: 4, R4: 8, R5: 16, R6: 32 KB (reaches ssthresh = 32 KB).\n2. Phase 2 (Congestion Avoidance): Linear growth: R7: 33 KB, R8: 34 KB ... R14: 40 KB.\n3. Loss Event at Round 14: Timeout occurs at cwnd = 40 KB.\n   - New ssthresh = cwnd / 2 = 20 KB.\n   - For both Tahoe and Reno, a TIMEOUT drops cwnd back to 1 KB (Note: Fast Recovery applies only to 3 Dup ACKs, not timeout).\n4. Post-Timeout Progression (Rounds 15-20):\n   - Round 15: 1 KB\n   - Round 16: 2 KB\n   - Round 17: 4 KB\n   - Round 18: 8 KB\n   - Round 19: 16 KB\n   - Round 20: Hits new ssthresh at 20 KB, transitions to linear increase (+1 KB).'
        },
        {
          id: 2,
          type: 'long',
          question: 'Analyze the TCP Connection Teardown process (4-Way Handshake) in detail. Include state transitions for both active and passive closers, and explain the architectural necessity of the TIME_WAIT state.',
          weightage: '10 Marks',
          keyPoints: [
            'Step 1: Active closer sends FIN, enters FIN_WAIT_1.',
            'Step 2: Passive closer sends ACK, enters CLOSE_WAIT; Active closer enters FIN_WAIT_2.',
            'Step 3: Passive closer finishes app data, sends FIN, enters LAST_ACK.',
            'Step 4: Active closer sends ACK, enters TIME_WAIT (2*MSL); Passive closer receives ACK and enters CLOSED.',
            'TIME_WAIT rationale: Retransmit final ACK if lost; prevent old delayed segments from resurrecting in new incarnation.'
          ],
          modelAnswer: 'TCP connection termination is symmetric because TCP is full-duplex, requiring two independent 2-way closes (total 4 segments):\n1. Active Close Initiation: Application calls close(). Host A sends FIN segment and transitions ESTABLISHED -> FIN_WAIT_1.\n2. Passive Acknowledgment: Host B receives FIN, sends ACK segment, and transitions ESTABLISHED -> CLOSE_WAIT. Host A receives ACK and transitions FIN_WAIT_1 -> FIN_WAIT_2. (Host B can still send data).\n3. Passive Close Completion: Host B application calls close(). Host B sends FIN segment and transitions CLOSE_WAIT -> LAST_ACK.\n4. Active Final ACK: Host A receives FIN, transmits ACK segment, and transitions FIN_WAIT_2 -> TIME_WAIT. Host B receives final ACK and transitions LAST_ACK -> CLOSED.\n\nNecessity of TIME_WAIT State (2 * MSL = typically 2-4 minutes):\n- Reason 1 (Reliable Teardown): If Host A’s final ACK is lost in transit, Host B will time out and retransmit its FIN. If Host A closed immediately without TIME_WAIT, it would reply with an RST, making Host B believe an error occurred.\n- Reason 2 (Old Segment Dissipation): Ensures any delayed segments wandering in the Internet routers from this connection expire before the same IP:port socket pair is reused for a new connection.'
        },
        {
          id: 3,
          type: 'long',
          question: 'Compare Sliding Window Flow Control with TCP Congestion Control. Explain how Silly Window Syndrome arises at both Sender and Receiver, and formulate Clark’s Solution and Nagle’s Algorithm.',
          weightage: '10 Marks',
          keyPoints: [
            'Flow Control: End-to-end receiver buffer protection using rwnd.',
            'Congestion Control: Network core router protection using cwnd.',
            'Effective Window: SendWindow = min(cwnd, rwnd).',
            'Silly Window Syndrome: Receiver side (consumes byte by byte) vs Sender side (app generates byte by byte).',
            'Clark’s Solution: Receiver must not advertise small window until min(MSS, Buffer/2) is free.',
            'Nagle’s Algorithm: Sender buffers small packets until full MSS or ACK received.'
          ],
          modelAnswer: '1. Flow Control vs Congestion Control:\n- Flow Control protects the receiving host from buffer overrun. It is controlled by rwnd advertised in TCP header.\n- Congestion Control protects intermediate router queues from packet drops and throughput collapse. It is controlled by sender-estimated cwnd.\n- The sender enforces: InFlight <= min(rwnd, cwnd).\n\n2. Silly Window Syndrome (SWS):\nSWS occurs when data is exchanged in extremely small segments (e.g. 1 byte payload with 40 bytes TCP/IP header = 97% overhead):\n- Receiver-caused SWS: Application consumes data 1 byte at a time and TCP immediately advertises rwnd = 1.\n- Sender-caused SWS: Application writes 1 byte at a time and TCP immediately transmits 41-byte packets.\n\n3. Solutions:\n- Clark’s Solution (Receiver-Side): The receiver prevents SWS by delaying window advertisement. It advertises rwnd = 0 until it can advertise a window of at least one full MSS or half the total receiver buffer size (RcvBuffer / 2).\n- Nagle’s Algorithm (Sender-Side): The sender transmits the first small byte immediately, but then buffers all subsequent user writes until all outstanding in-flight segments are acknowledged OR the accumulated buffer reaches 1 full MSS. This effectively bundles tiny writes into full segments without adding excessive latency.'
        }
      ]
    }
  }
];

