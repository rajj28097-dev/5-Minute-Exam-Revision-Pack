import { GoogleGenAI, Type } from '@google/genai';
import { RevisionPack } from '../types/revision';

// Prompt instructions enforcing the exact 6 sections
const PROMPT_INSTRUCTIONS = `
You are an elite university professor and academic examination specialist.
Analyze the uploaded notes/document carefully and create a comprehensive 5-Minute Exam Revision Pack.

STRICT INSTRUCTIONS & REQUIREMENTS:
- Use ONLY the provided notes/document as the primary source of truth.
- Do not skip important topics from the notes.
- Keep the language clear, simple, and easy to understand, while maintaining rigorous university/college exam level.
- Make the final pack highly useful for last-minute 5-minute revision before stepping into the exam hall.

You MUST produce ALL 6 sections in the structured JSON response:

1. 5-Minute Quick Summary:
   - Topic title and estimated reading time (e.g. "4 mins 30 secs").
   - Clear overview paragraph in simple English.
   - Structured sections with clear headings, bullet points, and key highlights:
     * Flag specific definitions, concepts, formulas, examples, keywords, differences, advantages/disadvantages, and important facts.
   - 4-6 ultra-condensed Speed Revision bullet points for a 60-second glance.

2. Important Exam Points ("Must Remember"):
   - 6 to 8 crucial takeaways that professors love to test in exams.
   - Categorize each point as: 'Core Formula/Rule', 'Vital Definition', 'Crucial Distinction', 'Frequent Exam Trap', or 'High-Yield Fact'.
   - Include why it is important for the exam and a short tag.

3. Exam-Level MCQs:
   - Exactly 20 multiple-choice questions strictly related to the notes.
   - 4 distinct options labeled A, B, C, D.
   - Appropriate for university/college exam level.
   - Blend of:
     * Concept-based questions
     * Definition-based questions
     * Application/numerical-based questions
     * Difference/comparison questions
     * Important factual questions
     * Tricky/confusing questions
   - Avoid questions whose answers are trivial or obvious.
   - Do not repeat the same concept unnecessarily.

4. Answer Key:
   - Provide an Answer Key for all 20 questions mapping questionNumber (1 to 20) to correctOption ('A', 'B', 'C', or 'D').

5. Short Explanation:
   - 1-2 line concise, razor-sharp explanation for each of the 20 answers, especially explaining tricky nuances.

6. Exam Practice:
   - 5 Very Important Questions (VIQs) with key points to score maximum marks and a concise model answer.
   - 5 Short-Answer Questions (typical 2-3 mark university exam questions with direct model answers).
   - 3 Long-Answer Questions (typical 8-15 mark university exam essay/numerical/architecture questions with structured outline points and comprehensive model answer).

Generate the response strictly as valid JSON adhering to the specified schema.
`;

export interface GenerateRevisionParams {
  textNotes?: string;
  fileData?: string;
  mimeType?: string;
  fileName?: string;
  userApiKey?: string;
}

export function getGeminiApiKey(customKey?: string): string {
  if (customKey && customKey.trim()) {
    return customKey.trim();
  }
  const viteKey = import.meta.env.VITE_GEMINI_API_KEY;
  if (viteKey && viteKey.trim() && viteKey !== 'MY_GEMINI_API_KEY') {
    return viteKey.trim();
  }
  const storedKey = localStorage.getItem('quickrevise_user_api_key');
  if (storedKey && storedKey.trim()) {
    return storedKey.trim();
  }
  return '';
}

export async function generateRevisionPackClient({
  textNotes,
  fileData,
  mimeType,
  fileName,
  userApiKey,
}: GenerateRevisionParams): Promise<RevisionPack> {
  const apiKey = getGeminiApiKey(userApiKey);

  if (!apiKey) {
    throw new Error(
      'Missing Gemini API Key. Please configure VITE_GEMINI_API_KEY in your environment variables (Netlify Site Settings > Environment variables) or enter your key in the app.'
    );
  }

  const parts: any[] = [];

  // Handle uploaded document
  if (fileData && mimeType) {
    if (
      mimeType === 'text/plain' ||
      mimeType === 'text/markdown' ||
      mimeType === 'application/json' ||
      mimeType === 'text/csv'
    ) {
      try {
        const decoded = atob(fileData);
        parts.push({
          text: `=== UPLOADED NOTES DOCUMENT (${fileName || 'Notes File'}): ===\n${decoded}\n=== END OF UPLOADED DOCUMENT ===\n\n`,
        });
      } catch {
        parts.push({
          inlineData: {
            mimeType: 'text/plain',
            data: fileData,
          },
        });
      }
    } else {
      // PDF or Images (PNG, JPG, WEBP)
      parts.push({
        inlineData: {
          mimeType: mimeType,
          data: fileData,
        },
      });
    }
  }

  if (textNotes && textNotes.trim()) {
    parts.push({
      text: `=== USER PROVIDED NOTES/TEXT: ===\n${textNotes.trim()}\n=== END OF USER NOTES ===\n\n`,
    });
  }

  parts.push({ text: PROMPT_INSTRUCTIONS });

  try {
    // Attempt standard @google/genai client call
    const ai = new GoogleGenAI({
      apiKey: apiKey,
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: { parts },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            sourceNoteSummary: { type: Type.STRING },
            quickSummary: {
              type: Type.OBJECT,
              properties: {
                topicTitle: { type: Type.STRING },
                estimatedReadTime: { type: Type.STRING },
                overview: { type: Type.STRING },
                sections: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      heading: { type: Type.STRING },
                      keyTakeaway: { type: Type.STRING },
                      bulletPoints: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                      },
                      highlights: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            label: { type: Type.STRING },
                            type: { type: Type.STRING },
                            text: { type: Type.STRING },
                          },
                          required: ['label', 'type', 'text'],
                        },
                      },
                    },
                    required: ['heading', 'keyTakeaway', 'bulletPoints'],
                  },
                },
                speedRevisionPoints: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
              },
              required: ['topicTitle', 'estimatedReadTime', 'overview', 'sections', 'speedRevisionPoints'],
            },
            mustRemember: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.INTEGER },
                  point: { type: Type.STRING },
                  category: { type: Type.STRING },
                  tag: { type: Type.STRING },
                  whyImportant: { type: Type.STRING },
                },
                required: ['id', 'point', 'category', 'tag', 'whyImportant'],
              },
            },
            mcqs: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.INTEGER },
                  questionNumber: { type: Type.INTEGER },
                  type: { type: Type.STRING },
                  question: { type: Type.STRING },
                  options: {
                    type: Type.OBJECT,
                    properties: {
                      A: { type: Type.STRING },
                      B: { type: Type.STRING },
                      C: { type: Type.STRING },
                      D: { type: Type.STRING },
                    },
                    required: ['A', 'B', 'C', 'D'],
                  },
                  correctOption: { type: Type.STRING },
                  explanation: { type: Type.STRING },
                },
                required: ['id', 'questionNumber', 'type', 'question', 'options', 'correctOption', 'explanation'],
              },
            },
            answerKey: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  questionNumber: { type: Type.INTEGER },
                  correctOption: { type: Type.STRING },
                },
                required: ['questionNumber', 'correctOption'],
              },
            },
            shortExplanations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  questionNumber: { type: Type.INTEGER },
                  correctOption: { type: Type.STRING },
                  explanation: { type: Type.STRING },
                },
                required: ['questionNumber', 'correctOption', 'explanation'],
              },
            },
            examPractice: {
              type: Type.OBJECT,
              properties: {
                veryImportantQuestions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.INTEGER },
                      type: { type: Type.STRING },
                      question: { type: Type.STRING },
                      weightage: { type: Type.STRING },
                      keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
                      modelAnswer: { type: Type.STRING },
                    },
                    required: ['id', 'type', 'question', 'modelAnswer'],
                  },
                },
                shortAnswerQuestions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.INTEGER },
                      type: { type: Type.STRING },
                      question: { type: Type.STRING },
                      weightage: { type: Type.STRING },
                      modelAnswer: { type: Type.STRING },
                    },
                    required: ['id', 'type', 'question', 'modelAnswer'],
                  },
                },
                longAnswerQuestions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.INTEGER },
                      type: { type: Type.STRING },
                      question: { type: Type.STRING },
                      weightage: { type: Type.STRING },
                      keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
                      modelAnswer: { type: Type.STRING },
                    },
                    required: ['id', 'type', 'question', 'modelAnswer'],
                  },
                },
              },
              required: ['veryImportantQuestions', 'shortAnswerQuestions', 'longAnswerQuestions'],
            },
          },
          required: [
            'title',
            'sourceNoteSummary',
            'quickSummary',
            'mustRemember',
            'mcqs',
            'answerKey',
            'shortExplanations',
            'examPractice',
          ],
        },
      },
    });

    const responseText = response.text || '';
    let parsed: any;
    try {
      parsed = JSON.parse(responseText);
    } catch {
      const cleaned = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      parsed = JSON.parse(cleaned);
    }

    return {
      id: `pack-${Date.now()}`,
      generatedAt: new Date().toISOString(),
      ...parsed,
    };
  } catch (err: any) {
    // If standard SDK encountered issues or direct REST fallback needed
    console.warn('Falling back to direct REST Gemini endpoint if SDK failed:', err);

    // Direct REST API call to Gemini
    const restUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${apiKey}`;
    const payload = {
      contents: [{ parts }],
      generationConfig: {
        responseMimeType: 'application/json',
      },
    };

    const restRes = await fetch(restUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!restRes.ok) {
      const errJson = await restRes.json().catch(() => ({}));
      throw new Error(
        errJson?.error?.message || err?.message || 'Gemini API generation failed. Please verify your VITE_GEMINI_API_KEY.'
      );
    }

    const restData = await restRes.json();
    const candidateText = restData?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!candidateText) {
      throw new Error('No content generated from Gemini. Please check note contents.');
    }

    let parsed: any;
    try {
      parsed = JSON.parse(candidateText);
    } catch {
      const cleaned = candidateText.replace(/```json/g, '').replace(/```/g, '').trim();
      parsed = JSON.parse(cleaned);
    }

    return {
      id: `pack-${Date.now()}`,
      generatedAt: new Date().toISOString(),
      ...parsed,
    };
  }
}
