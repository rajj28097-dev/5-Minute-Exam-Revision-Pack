export interface KeyHighlight {
  label: string;
  type: 'definition' | 'formula' | 'difference' | 'advantage_disadvantage' | 'fact' | 'keyword';
  text: string;
}

export interface SummarySection {
  heading: string;
  keyTakeaway: string;
  bulletPoints: string[];
  highlights?: KeyHighlight[];
}

export interface QuickSummary {
  topicTitle: string;
  estimatedReadTime: string; // e.g. "4-5 mins"
  overview: string;
  sections: SummarySection[];
  speedRevisionPoints: string[];
}

export interface MustRememberPoint {
  id: number;
  point: string;
  category: 'Core Formula/Rule' | 'Vital Definition' | 'Crucial Distinction' | 'Frequent Exam Trap' | 'High-Yield Fact';
  tag: string;
  whyImportant: string;
}

export type MCQType =
  | 'concept-based'
  | 'definition-based'
  | 'application-based'
  | 'difference-based'
  | 'factual'
  | 'tricky';

export interface MCQOption {
  key: 'A' | 'B' | 'C' | 'D';
  text: string;
}

export interface MCQItem {
  id: number;
  questionNumber: number;
  type: MCQType;
  question: string;
  options: {
    A: string;
    B: string;
    C: string;
    D: string;
  };
  correctOption: 'A' | 'B' | 'C' | 'D';
  explanation: string;
}

export interface AnswerKeyEntry {
  questionNumber: number;
  correctOption: 'A' | 'B' | 'C' | 'D';
}

export interface PracticeQuestion {
  id: number;
  type: 'VIQ' | 'short' | 'long';
  question: string;
  weightage?: string; // e.g. "5 Marks", "2-3 Marks", "10-15 Marks"
  keyPoints?: string[];
  modelAnswer: string;
}

export interface ExamPracticeSection {
  veryImportantQuestions: PracticeQuestion[]; // exactly 5
  shortAnswerQuestions: PracticeQuestion[]; // exactly 5
  longAnswerQuestions: PracticeQuestion[]; // exactly 3
}

export interface RevisionPack {
  id: string;
  title: string;
  sourceNoteSummary: string;
  generatedAt: string;
  totalWordsEstimated?: number;
  quickSummary: QuickSummary;
  mustRemember: MustRememberPoint[];
  mcqs: MCQItem[]; // exactly 20
  answerKey: AnswerKeyEntry[]; // 1 to 20
  shortExplanations: { questionNumber: number; correctOption: 'A' | 'B' | 'C' | 'D'; explanation: string }[];
  examPractice: ExamPracticeSection;
}
